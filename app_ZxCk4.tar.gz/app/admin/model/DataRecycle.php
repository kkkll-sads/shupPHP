<?php

namespace app\admin\model;

use think\Model;

/**
 * DataRecycle 模型
 */
class DataRecycle extends Model
{
    protected $name = 'security_data_recycle';

    protected $autoWriteTimestamp = true;
}