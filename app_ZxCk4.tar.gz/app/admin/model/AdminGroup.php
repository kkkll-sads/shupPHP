<?php

namespace app\admin\model;

use think\Model;

/**
 * AdminGroup模型
 */
class AdminGroup extends Model
{
    protected $autoWriteTimestamp = true;
}