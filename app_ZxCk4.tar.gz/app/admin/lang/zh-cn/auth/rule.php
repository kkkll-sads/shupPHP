<?php
return [
    'type'  => '规则类型',
    'title' => '规则标题',
    'name'  => '规则名称',
];