<?php
return [
    'Group Name Arr'                                                           => '管理员分组',
    'Please use another administrator account to disable the current account!' => '请使用另外的管理员账户禁用当前账户！',
    'You have no permission to add an administrator to this group!'            => '您没有权限向此分组添加管理员！',
];