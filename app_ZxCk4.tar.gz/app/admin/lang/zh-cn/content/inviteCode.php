<?php
return [
    'Code'                      => '邀请码',
    'Creator'                   => '创建者(手机号)',
    'Upuser'                    => '上级用户(手机号)',
    'Child count'               => '下级用户数',
    'Status'                    => '状态',
    'Use count'                 => '已使用次数',
    'Max use'                   => '最大使用次数',
    'Expire time'               => '过期时间',
    'Remark'                    => '备注',
    'Auto generate tip'         => '留空则自动生成',
    'Max use tip'               => '0表示不限制使用次数',
    'Expire time tip'           => '留空则永不过期',
    'Invite code management'    => '邀请码管理',
    'Add invite code'           => '添加邀请码',
    'Edit invite code'          => '编辑邀请码',
    'Delete invite code'        => '删除邀请码',
];

