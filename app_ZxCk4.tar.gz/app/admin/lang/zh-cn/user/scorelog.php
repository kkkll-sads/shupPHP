<?php
return [
    'user_id'                     => '用户',
    'score'                       => '变更积分',
    'memo'                        => '变更备注',
    "The user can't find it"      => '用户找不到啦',
    'Change note cannot be blank' => '变更备注不能为空',
];