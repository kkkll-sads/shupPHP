<?php
return [
    'No rows were rollback' => '没有记录被回滚',
];