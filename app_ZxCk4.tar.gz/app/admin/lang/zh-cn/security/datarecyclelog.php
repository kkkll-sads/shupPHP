<?php
return [
    'No rows were restore' => '没有记录被还原',
];