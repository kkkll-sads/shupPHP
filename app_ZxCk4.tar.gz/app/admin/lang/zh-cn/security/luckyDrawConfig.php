<?php
return [
    'Id'                        => 'ID',
    'Config key'                => '配置键',
    'Config value'              => '配置值',
    'Remark'                    => '备注',
    'Create time'               => '创建时间',
    'Update time'               => '更新时间',
    'Lucky draw config'         => '幸运转盘配置',
    'Edit config'               => '编辑配置',
    'Daily draw limit'          => '每天允许抽奖次数',
    'Draw score cost'           => '每次抽奖消耗积分',
    'Daily limit reset hour'    => '每日限制重置时间(小时)',
    'Prize send auto'           => '是否自动发放奖品',
];

