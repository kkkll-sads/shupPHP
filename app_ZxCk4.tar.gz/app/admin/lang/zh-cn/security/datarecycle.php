<?php
return [
    'Name'        => '规则名称',
    'Controller'  => '控制器',
    'Data Table'  => '对应数据表',
    'Primary Key' => '数据表主键',
    'Remark lang' => '在此定义需要回收的数据，实现数据自动统一回收',
];