<?php
return [
    'No background menu, please contact super administrator!'       => '无后台菜单，请联系超级管理员！',
    'You have already logged in. There is no need to log in again~' => '您已经登录过了，无需重复登录~',
    'Login succeeded!'                                              => '登录成功！',
    'Incorrect user name or password!'                              => '用户名或密码不正确！',
    'Login'                                                         => '登录',
    'Logout'                                                        => '注销登录',
];
