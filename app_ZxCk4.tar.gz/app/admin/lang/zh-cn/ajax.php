<?php
return [
    'Start the database migration'                                                                  => '开始进行数据库迁移',
    'Start formatting the web project code'                                                         => '开始格式化前端代码（失败无影响，代码编辑器内按需的手动格式化即可）',
    'Start installing the composer dependencies'                                                    => '开始安装服务端依赖',
    'Start executing the build command of the web project'                                          => '开始执行 web 工程的 build 命令，成功后会自动将构建产物移动至 根目录/public 目录下',
    'Failed to modify the terminal configuration. Please modify the configuration file manually:%s' => '修改终端配置失败，请手动修改配置文件：%s',
    'upload'                                                                                        => '上传文件',
    'Change terminal config'                                                                        => '修改终端配置',
    'Clear cache'                                                                                   => '清理缓存',
    'Data table does not exist'                                                                     => '数据表不存在~',
];