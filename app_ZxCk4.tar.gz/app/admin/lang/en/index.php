<?php
return [
    'No background menu, please contact super administrator!'       => 'No background menu, please contact the super administrator!',
    'You have already logged in. There is no need to log in again~' => 'You have already logged in, no need to log in again.',
    'Login succeeded!'                                              => 'Login successful!',
    'Incorrect user name or password!'                              => 'Incorrect username or password!',
    'Login'                                                         => 'Login',
    'Logout'                                                        => 'Logout',
];