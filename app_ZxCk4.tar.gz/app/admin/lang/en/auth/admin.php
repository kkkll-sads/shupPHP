<?php
return [
    'Group Name Arr'                                                           => 'Administrator Grouping ',
    'Please use another administrator account to disable the current account!' => 'Disable the current account, please use another administrator account!',
];