<?php
return [
    '%d records and files have been deleted' => '%d records and files have been deleted',
    'remark_text'                            => 'When the same file is uploaded multiple times, only one copy will be saved to the disk and an attachment record will be added; Deleting an attachment record will automatically delete the corresponding file!',
];