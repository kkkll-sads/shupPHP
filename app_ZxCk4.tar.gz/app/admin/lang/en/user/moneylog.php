<?php
return [
    'user_id'                     => 'User',
    'money'                       => 'Change amount',
    'memo'                        => 'Change Notes',
    "The user can't find it"      => "User does not exist",
    'Change note cannot be blank' => 'Change Notes cannot be empty',
];