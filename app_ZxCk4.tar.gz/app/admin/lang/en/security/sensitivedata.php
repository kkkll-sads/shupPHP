<?php
return [
    'Name'        => 'Rule name',
    'Controller'  => 'Controller',
    'Data Table'  => 'Corresponding data table',
    'Primary Key' => 'Data table primary key',
    'Data Fields' => 'Sensitive data fields',
];