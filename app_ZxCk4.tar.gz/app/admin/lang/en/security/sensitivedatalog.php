<?php
return [
    'No rows were rollback' => 'No records have been roll-back',
];