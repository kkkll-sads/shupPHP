<?php
return [
    'No rows were restore' => 'No records have been restored',
];