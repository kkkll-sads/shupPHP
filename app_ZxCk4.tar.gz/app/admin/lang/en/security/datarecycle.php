<?php
return [
    'Name'        => 'Rule Name',
    'Controller'  => 'Controller',
    'Data Table'  => 'Corresponding data table',
    'Primary Key' => 'Data table primary key',
];