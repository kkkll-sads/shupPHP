<?php
return [
    'change-field-name fail not exist' => 'Field %s failed to be renamed because the field does not exist in the data table',
    'del-field fail not exist'         => 'Failed to delete field %s because the field does not exist in the data table',
    'change-field-attr fail not exist' => 'Description Failed to modify the properties of field %s because the field does not exist in the data table',
    'add-field fail exist'             => 'Failed to add field %s because the field already exists in the data table',
];