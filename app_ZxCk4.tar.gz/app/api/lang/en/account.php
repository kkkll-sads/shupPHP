<?php
return [
    'nickname'                                           => 'Nickname',
    'birthday'                                           => 'Birthday',
    'captcha'                                            => 'Captcha',
    'Old password error'                                 => 'Old password error',
    'Data updated successfully~'                         => 'Data updated successfully',
    'Please input correct password'                      => 'Please enter the correct password',
    'nicknameChsDash'                                    => 'Usernames can only be Chinese characters, letters, numbers, underscores_ and dashes-.',
    'Password has been changed~'                         => 'Password has been changed~',
    'Password has been changed, please login again~'     => 'Password has been changed, please login again~',
    'Account does not exist~'                            => 'Account does not exist',
    'Failed to modify password, please try again later~' => 'Failed to modify password, please try again later~',
    'Please enter the correct verification code'         => 'Please enter the correct Captcha',
    '%s has been registered'                             => '%s has been registered, please login directly.',
];