<?php
return [
    'email format error'                                => 'email format error',
    'user_register'                                     => 'Member registration verification',
    'user_retrieve_pwd'                                 => 'Retrieve password verification',
    'user_change_email'                                 => 'Modify mailbox validation',
    'user_email_verify'                                 => 'Member Email Verification',
    'Your verification code is: %s'                     => 'Your Captcha is: %s，valid for 10 minutes~',
    'Mail sent successfully~'                           => 'Mail sent successfully',
    'Account does not exist~'                           => 'Account does not exist',
    'Mail sending service unavailable'                  => 'The mail sending service is not working, please contact the webmaster to configure it.',
    'Frequent email sending'                            => 'Frequent email sending',
    'Email has been registered, please log in directly' => 'Email has been registered, please log in directly~',
    'The email has been occupied'                       => 'The email has been occupied',
    'Email not registered'                              => 'Email not registered',
];