<?php
return [
    'Id' => 'ID',
    'Applicant Type' => '申请方类型',
    'Applicant Id' => '申请方ID',
    'Applicant Name' => '申请方名称',
    'Amount' => '提现金额',
    'Status' => '状态',
    'Apply Reason' => '申请说明',
    'Audit Remark' => '审核备注',
    'Audit Admin Id' => '审核管理员ID',
    'Audit Time' => '审核时间',
    'Create Time' => '创建时间',
    'Update Time' => '更新时间',
    'Withdraw Review Management' => '提现审核管理',
    'Add Withdraw Review' => '新增提现审核',
    'Edit Withdraw Review' => '编辑提现审核',
    'Invalid status value' => '状态取值不正确',
    'Invalid applicant type' => '申请方类型不正确',
];

