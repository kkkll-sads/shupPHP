<?php
return [
    'Please input correct username' => 'Please enter the correct username',
    'Please input correct password' => 'Please enter the correct password',
    'Avatar modified successfully!' => 'Profile picture modified successfully！',
];