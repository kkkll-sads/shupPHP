<?php
return [
    'Super administrator'                          => 'Super administrator',
    'No permission'                                => 'No permission',
    'You cannot modify your own management group!' => 'You cannot modify your own management group!',
];
