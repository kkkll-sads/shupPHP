<?php
return [
    'type'  => 'Rule type',
    'title' => 'Rule title',
    'name'  => 'Rule name',
];