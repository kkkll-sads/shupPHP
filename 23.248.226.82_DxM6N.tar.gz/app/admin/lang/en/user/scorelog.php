<?php
return [
    'user_id'                     => 'User',
    'score'                       => 'Change points',
    'memo'                        => 'Change Notes',
    "The user can't find it"      => 'User does not exist',
    'Change note cannot be blank' => 'Change notes cannot be empty',
];