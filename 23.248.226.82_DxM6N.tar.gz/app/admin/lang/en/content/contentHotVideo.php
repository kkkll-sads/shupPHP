<?php
return [
    'Id' => 'ID',
    'Title' => 'Title',
    'Summary' => 'Summary',
    'Video Url' => 'Video Url',
    'Cover Image' => 'Cover Image',
    'Status' => 'Status',
    'Publish Time' => 'Publish Time',
    'Sort' => 'Sort',
    'View Count' => 'View Count',
    'Createtime' => 'Create Time',
    'Updatetime' => 'Update Time',
    'Title is required' => 'Title is required',
    'Status value is incorrect' => 'Status value is incorrect',
    'Value is incorrect' => 'Value is incorrect',
    'Hot Video Management' => 'Hot Video Management',
    'Add Hot Video' => 'Add Hot Video',
    'Edit Hot Video' => 'Edit Hot Video',
];

