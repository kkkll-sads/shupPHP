<?php
return [
    'Id' => 'ID',
    'Title' => 'Title',
    'Summary' => 'Summary',
    'Cover Image' => 'Cover Image',
    'Content' => 'Content',
    'Link Url' => 'Link Url',
    'Is Hot' => 'Hot',
    'Status' => 'Status',
    'Publish Time' => 'Publish Time',
    'Sort' => 'Sort',
    'View Count' => 'View Count',
    'Createtime' => 'Create Time',
    'Updatetime' => 'Update Time',
    'Title is required' => 'Title is required',
    'Status value is incorrect' => 'Status value is incorrect',
    'Value is incorrect' => 'Value is incorrect',
    'News Management' => 'News Management',
    'Add News' => 'Add News',
    'Edit News' => 'Edit News',
];


