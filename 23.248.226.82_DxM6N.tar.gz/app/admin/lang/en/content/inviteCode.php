<?php
return [
    'Code'                      => 'Invite Code',
    'Creator'                   => 'Creator(Mobile)',
    'Upuser'                    => 'Upline User(Mobile)',
    'Child count'               => 'Child Users',
    'Status'                    => 'Status',
    'Use count'                 => 'Used Count',
    'Max use'                   => 'Max Usage',
    'Expire time'               => 'Expire Time',
    'Remark'                    => 'Remark',
    'Auto generate tip'         => 'Leave blank to auto-generate',
    'Max use tip'               => '0 means unlimited usage',
    'Expire time tip'           => 'Leave blank for never expire',
    'Invite code management'    => 'Invite Code Management',
    'Add invite code'           => 'Add Invite Code',
    'Edit invite code'          => 'Edit Invite Code',
    'Delete invite code'        => 'Delete Invite Code',
];

