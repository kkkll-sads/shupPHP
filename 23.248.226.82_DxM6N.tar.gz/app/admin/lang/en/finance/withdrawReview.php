<?php
return [
    'Id' => 'ID',
    'Applicant Type' => 'Applicant Type',
    'Applicant Id' => 'Applicant ID',
    'Applicant Name' => 'Applicant Name',
    'Amount' => 'Withdraw Amount',
    'Status' => 'Status',
    'Apply Reason' => 'Apply Reason',
    'Audit Remark' => 'Audit Remark',
    'Audit Admin Id' => 'Audit Admin ID',
    'Audit Time' => 'Audit Time',
    'Create Time' => 'Create Time',
    'Update Time' => 'Update Time',
    'Withdraw Review Management' => 'Withdraw Review Management',
    'Add Withdraw Review' => 'Add Withdraw Review',
    'Edit Withdraw Review' => 'Edit Withdraw Review',
    'Invalid status value' => 'Invalid status value',
    'Invalid applicant type' => 'Invalid applicant type',
];

