<?php
return [
    'Id'                        => 'ID',
    'Config key'                => 'Config Key',
    'Config value'              => 'Config Value',
    'Remark'                    => 'Remark',
    'Create time'               => 'Created At',
    'Update time'               => 'Updated At',
    'Lucky draw config'         => 'Lucky Draw Config',
    'Edit config'               => 'Edit Config',
    'Daily draw limit'          => 'Daily Draw Limit',
    'Draw score cost'           => 'Score Cost Per Draw',
    'Daily limit reset hour'    => 'Daily Limit Reset Hour',
    'Prize send auto'           => 'Auto Send Prize',
];

