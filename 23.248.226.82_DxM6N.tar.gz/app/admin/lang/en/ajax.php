<?php
return [
    'Failed to switch package manager. Please modify the configuration file manually:%s'            => 'Failed to switch package manager, please modify the configuration file manually:%s',
    'Failed to modify the terminal configuration. Please modify the configuration file manually:%s' => 'Failed to modify the terminal configuration, please modify the configuration file manually:%s',
    'upload'                                                                                        => 'Upload files',
    'Change terminal config'                                                                        => 'Modify terminal configuration',
    'Clear cache'                                                                                   => 'Clear cache',
    'Data table does not exist'                                                                     => 'Data table does not exist',
];