<?php
return [
    'Parse field data'                 => 'CRUD代码生成-解析字段数据',
    'Log start'                        => 'CRUD代码生成-从历史记录开始',
    'Generate check'                   => 'CRUD代码生成-生成前预检',
    'change-field-name fail not exist' => '字段 %s 改名失败，数据表内不存在该字段',
    'del-field fail not exist'         => '字段 %s 删除失败，数据表内不存在该字段',
    'change-field-attr fail not exist' => '修改字段 %s 的属性失败，数据表内不存在该字段',
    'add-field fail exist'             => '添加字段 %s 失败，数据表内已经存在该字段',
    'Failed to load cloud data'        => '加载云端数据失败，请稍后重试！',
];