<?php
return [
    'Name'        => '规则名称',
    'Controller'  => '控制器',
    'Data Table'  => '对应数据表',
    'Primary Key' => '数据表主键',
    'Data Fields' => '敏感数据字段',
    'Remark lang' => '在此定义需要保护的敏感字段，随后系统将自动监听该字段的修改操作，并提供了敏感字段的修改回滚功能',
];