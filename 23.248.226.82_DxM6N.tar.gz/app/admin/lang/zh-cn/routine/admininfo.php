<?php
return [
    'Please input correct username' => '请输入正确的用户名',
    'Please input correct password' => '请输入正确的密码',
    'Avatar modified successfully!' => '头像修改成功！',
];