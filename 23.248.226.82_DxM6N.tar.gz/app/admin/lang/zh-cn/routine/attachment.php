<?php
return [
    'Remark lang'                            => '同一文件被多次上传时，只会保存一份至磁盘和增加一条附件记录；删除附件记录，将自动删除对应文件！',
    '%d records and files have been deleted' => '删除了%d条记录和文件',
];