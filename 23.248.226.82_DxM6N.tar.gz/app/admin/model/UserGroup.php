<?php

namespace app\admin\model;

use think\Model;

/**
 * UserGroup 模型
 */
class UserGroup extends Model
{
    protected $autoWriteTimestamp = true;
}