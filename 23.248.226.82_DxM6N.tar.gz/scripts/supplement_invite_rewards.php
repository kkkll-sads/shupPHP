<?php
/**
 * 补发实名认证邀请奖励脚本
 * 为那些实名认证已通过但邀请人未收到奖励的用户补发邀请奖励
 *
 * 使用方法:
 * php scripts/supplement_invite_rewards.php
 */

require __DIR__ . '/../vendor/autoload.php';

$app = new think\App();
$app->initialize();

use think\facade\Db;
use think\facade\Log;

class SupplementInviteRewards
{
    private $processedCount = 0;
    private $rewardedCount = 0;
    private $skippedCount = 0;
    private $errorCount = 0;

    public function __construct()
    {
        echo "========================================\n";
        echo "补发实名认证邀请奖励脚本\n";
        echo "========================================\n\n";
    }

    /**
     * 运行补发脚本
     */
    public function run()
    {
        try {
            // 获取所有实名认证已通过的用户
            $this->processRealNameUsers();
            $this->printSummary();

        } catch (\Exception $e) {
            echo "❌ 脚本执行失败: " . $e->getMessage() . "\n";
            echo $e->getTraceAsString() . "\n";
        }
    }

    /**
     * 处理实名认证已通过的用户
     */
    private function processRealNameUsers()
    {
        echo "📋 开始处理实名认证用户...\n";
        echo "----------------------------------------\n";

        // 获取所有实名认证已通过的用户
        $realNameUsers = Db::name('user')
            ->where('real_name_status', 2) // 已通过实名认证
            ->where('inviter_id', '>', 0) // 有邀请人
            ->field('id, username, inviter_id, real_name, create_time')
            ->select()
            ->toArray();

        echo "找到 " . count($realNameUsers) . " 个实名认证已通过且有邀请人的用户\n\n";

        foreach ($realNameUsers as $user) {
            $this->processedCount++;
            $this->processUser($user);
        }
    }

    /**
     * 处理单个用户
     */
    private function processUser($user)
    {
        echo "处理用户: {$user['username']} (ID: {$user['id']})\n";

        try {
            // 检查是否已经发放过邀请奖励
            $existingReward = Db::name('user_activity_log')
                ->where('user_id', $user['inviter_id'])
                ->where('related_user_id', $user['id'])
                ->where('action_type', 'invite_reward')
                ->find();

            if ($existingReward) {
                echo "  ⚠️ 已发放过邀请奖励，跳过\n";
                $this->skippedCount++;
                return;
            }

            // 检查邀请人是否存在
            $inviter = Db::name('user')
                ->where('id', $user['inviter_id'])
                ->field('id, username, status')
                ->find();

            if (!$inviter) {
                echo "  ❌ 邀请人不存在，跳过\n";
                $this->skippedCount++;
                return;
            }

            if ($inviter['status'] != 'enable') {
                echo "  ❌ 邀请人账户已禁用，跳过\n";
                $this->skippedCount++;
                return;
            }

            // 检查是否有有效的活动
            $activity = Db::name('sign_in_activity')
                ->where('status', 1)
                ->find();

            if (!$activity) {
                echo "  ❌ 没有有效的邀请活动，跳过\n";
                $this->skippedCount++;
                return;
            }

            $inviteRewardMin = (float)$activity['invite_reward_min'];
            $inviteRewardMax = (float)$activity['invite_reward_max'];

            if ($inviteRewardMin <= 0 || $inviteRewardMax <= 0) {
                echo "  ❌ 邀请奖励金额配置无效，跳过\n";
                $this->skippedCount++;
                return;
            }

            // 生成随机奖励金额
            $inviteReward = $this->generateRandomMoney($inviteRewardMin, $inviteRewardMax);

            // 发放奖励
            $this->grantInviteReward($user['inviter_id'], $user['id'], $inviteReward, $activity);

            echo "  ✅ 补发邀请奖励成功: {$inviteReward} 元给邀请人 {$inviter['username']}\n";
            $this->rewardedCount++;

        } catch (\Exception $e) {
            echo "  ❌ 处理失败: " . $e->getMessage() . "\n";
            Log::error('补发邀请奖励失败', [
                'user_id' => $user['id'],
                'inviter_id' => $user['inviter_id'],
                'error' => $e->getMessage()
            ]);
            $this->errorCount++;
        }

        echo "\n";
    }

    /**
     * 发放邀请奖励
     */
    private function grantInviteReward($inviterId, $newUserId, $inviteReward, $activity)
    {
        Db::transaction(function () use ($inviterId, $newUserId, $inviteReward, $activity) {
            // 获取邀请人信息
            $inviter = \app\common\model\User::where('id', $inviterId)->lock(true)->find();
            if (!$inviter) {
                throw new \Exception('邀请人不存在');
            }

            $beforeWithdrawable = (float)$inviter->withdrawable_money;
            $afterWithdrawable = round($beforeWithdrawable + $inviteReward, 2);
            $inviter->withdrawable_money = $afterWithdrawable;
            $inviter->save();

            // 记录资金变动日志
            $now = time();
            $flowNo = 'SJS' . date('YmdHis') . str_pad($inviterId, 6, '0', STR_PAD_LEFT) . rand(100, 999);
            $batchNo = 'INVITE_SUP_' . date('Ymd') . '_' . str_pad($newUserId, 8, '0', STR_PAD_LEFT);
            Db::name('user_money_log')->insert([
                'user_id' => $inviterId,
                'field_type' => 'withdrawable_money',
                'money' => $inviteReward,
                'before' => $beforeWithdrawable,
                'after' => $afterWithdrawable,
                'memo' => sprintf('补发邀请好友获得金额：%.2f元（被邀请用户ID：%d）', $inviteReward, $newUserId),
                'flow_no' => $flowNo,
                'batch_no' => $batchNo,
                'biz_type' => 'invite_reward',
                'biz_id' => $newUserId,
                'create_time' => $now,
            ]);

            // 记录活动日志
            \app\common\model\UserActivityLog::create([
                'user_id' => $inviterId,
                'related_user_id' => $newUserId,
                'action_type' => 'invite_reward',
                'change_field' => 'withdrawable_money',
                'change_value' => $inviteReward,
                'before_value' => $beforeWithdrawable,
                'after_value' => $afterWithdrawable,
                'remark' => sprintf('补发邀请好友获得金额：%.2f元（被邀请用户ID：%d）', $inviteReward, $newUserId),
                'extra' => [
                    'activity_id' => $activity['id'],
                    'activity_name' => $activity['name'],
                    'fund_source' => $activity['fund_source'],
                    'invite_reward' => $inviteReward,
                    'invited_user_id' => $newUserId,
                    'supplement' => true, // 标记为补发
                ],
            ]);
        });
    }

    /**
     * 生成随机金额
     */
    private function generateRandomMoney(float $min, float $max): float
    {
        if ($min >= $max) {
            return $min;
        }
        // 生成0.01精度的随机金额
        $random = mt_rand((int)($min * 100), (int)($max * 100)) / 100;
        return round($random, 2);
    }

    /**
     * 打印总结
     */
    private function printSummary()
    {
        echo "========================================\n";
        echo "补发结果总结\n";
        echo "========================================\n";
        echo "总处理用户数: {$this->processedCount}\n";
        echo "成功补发奖励: {$this->rewardedCount}\n";
        echo "跳过（已发放）: {$this->skippedCount}\n";
        echo "处理失败: {$this->errorCount}\n";
        echo "========================================\n";

        if ($this->rewardedCount > 0) {
            echo "✅ 补发完成！成功为 {$this->rewardedCount} 个邀请人补发了邀请奖励\n";
        } else {
            echo "ℹ️ 没有需要补发的邀请奖励\n";
        }
    }
}

// 执行补发脚本
$script = new SupplementInviteRewards();
$script->run();

