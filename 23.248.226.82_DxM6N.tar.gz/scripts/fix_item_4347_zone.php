<?php
/**
 * 修复 Item 4347 (Asset 37-DATA-0040-0009) 的 Zone ID
 * 当前: Zone 9 (1300元区), 价格 1229.71
 * 目标: Zone 8 (1200元区)
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$itemId = 4347;

echo "正在修复 Item ID {$itemId} ...\n";

$item = Db::name('collection_item')->find($itemId);
if (!$item) {
    echo "Item 不存在!\n";
    exit;
}

echo "当前 Zone: {$item['zone_id']} ({$item['price_zone']}), Price: {$item['price']}\n";

if ($item['zone_id'] == 9) {
    Db::name('collection_item')
        ->where('id', $itemId)
        ->update([
            'zone_id' => 8,
            'price_zone' => '1200元区',
            'update_time' => time()
        ]);
    
    echo "已修复为 Zone 8 (1200元区)。\n";
} else {
    echo "无需修复或状态不符。\n";
}
