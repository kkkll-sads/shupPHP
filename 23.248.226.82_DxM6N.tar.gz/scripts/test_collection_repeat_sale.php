<?php
/**
 * 测试单个藏品多次转手增值和转矿机分红
 * 
 * 使用方法:
 * php scripts/test_collection_repeat_sale.php [user_id] [rounds]
 */

require __DIR__ . '/../vendor/autoload.php';

$app = new think\App();
$app->initialize();

use think\facade\Db;

// 辅助函数
if (!function_exists('generateSJSFlowNo')) {
    function generateSJSFlowNo($userId) {
        return 'SJS' . date('YmdHis') . str_pad((string)$userId, 6, '0', STR_PAD_LEFT) . rand(100, 999);
    }
}

if (!function_exists('generateBatchNo')) {
    function generateBatchNo($prefix, $id) {
        return $prefix . '_' . date('Ymd') . '_' . str_pad((string)$id, 8, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('generateFlowNo')) {
    function generateFlowNo() {
        return 'FL' . date('YmdHis') . rand(100000, 999999);
    }
}

class CollectionRepeatSaleTest
{
    private $testUsers = [];
    private $testResults = [];
    private $originalItemId = 0;
    private $transactionHistory = [];

    public function __construct()
    {
        echo "========================================\n";
        echo "藏品多次转手增值和转矿机分红测试\n";
        echo "========================================\n\n";
    }

    /**
     * 运行测试
     */
    public function runTest($startUserId = null, $rounds = 5)
    {
        try {
            // 1. 准备测试数据
            $this->prepareTestData($startUserId);
            
            // 2. 创建初始藏品
            $this->createInitialCollection();
            
            // 3. 多次转手交易
            $this->repeatTransactions($rounds);
            
            // 4. 转矿机分红
            $this->testMiningDividend();
            
            // 5. 输出测试结果
            $this->printTestResults();
            
        } catch (\Exception $e) {
            echo "❌ 测试执行失败: " . $e->getMessage() . "\n";
            echo $e->getTraceAsString() . "\n";
        }
    }

    /**
     * 准备测试数据
     */
    private function prepareTestData($startUserId = null)
    {
        echo "📋 步骤 1: 准备测试数据\n";
        echo "----------------------------------------\n";
        
        // 使用已存在的测试用户或创建新用户
        if ($startUserId) {
            $user = Db::name('user')->where('id', $startUserId)->find();
            if (!$user) {
                throw new \Exception("用户不存在: {$startUserId}");
            }
            $this->testUsers[] = $user;
        }
        
        // 获取5个测试用户（循环使用）
        $existingUsers = Db::name('user')
            ->where('id', 'in', [176, 177, 178, 179, 180])
            ->field('id, username, mobile, balance_available, service_fee_balance')
            ->select()
            ->toArray();
        
        if (count($existingUsers) < 5) {
            throw new \Exception('测试用户不足，需要至少5个用户');
        }
        
        $this->testUsers = array_slice($existingUsers, 0, 5);
        
        // 确保所有用户有足够的余额和确权金
        foreach ($this->testUsers as $user) {
            Db::name('user')
                ->where('id', $user['id'])
                ->update([
                    'balance_available' => 50000,
                    'withdrawable_money' => 10000,
                    'service_fee_balance' => 5000,
                    'money' => 60000,
                    'update_time' => time(),
                ]);
        }
        
        echo "✓ 准备5个测试用户:\n";
        foreach ($this->testUsers as $idx => $user) {
            echo "  " . ($idx + 1) . ". ID={$user['id']}, 用户名={$user['username']}\n";
        }
        echo "\n";
    }

    /**
     * 创建初始藏品
     */
    private function createInitialCollection()
    {
        echo "📋 步骤 2: 创建初始藏品\n";
        echo "----------------------------------------\n";
        
        $session = Db::name('collection_session')
            ->where('status', '1')
            ->order('id desc')
            ->find();
        
        if (!$session) {
            throw new \Exception('没有可用的交易场次');
        }
        
        $zone = Db::name('price_zone_config')
            ->where('status', '1')
            ->order('min_price asc')
            ->limit(1)
            ->find();
        
        if (!$zone) {
            throw new \Exception('没有可用的价格分区');
        }
        
        $now = time();
        $initialPrice = 1000.00;
        
        // 创建藏品SPU
        $itemId = Db::name('collection_item')->insertGetId([
            'title' => '测试转手藏品-' . date('YmdHis'),
            'image' => '',
            'price' => $initialPrice,
            'issue_price' => $initialPrice,
            'session_id' => $session['id'],
            'zone_id' => $zone['id'],
            'price_zone' => $zone['name'],
            'stock' => 0,
            'status' => '1',
            'create_time' => $now,
            'update_time' => $now,
        ]);
        
        $this->originalItemId = $itemId;
        
        // 创建第一个用户的藏品记录
        $firstUser = $this->testUsers[0];
        $userCollectionId = Db::name('user_collection')->insertGetId([
            'user_id' => $firstUser['id'],
            'order_id' => 0,
            'order_item_id' => 0,
            'item_id' => $itemId,
            'title' => '测试转手藏品',
            'image' => '',
            'price' => $initialPrice,
            'buy_time' => $now,
            'delivery_status' => 0,
            'consignment_status' => 0,
            'mining_status' => 0,
            'create_time' => $now,
            'update_time' => $now,
        ]);
        
        echo "✓ 创建初始藏品\n";
        echo "  - 藏品ID: {$itemId}\n";
        echo "  - 用户藏品ID: {$userCollectionId}\n";
        echo "  - 初始价格: {$initialPrice}元\n";
        echo "  - 持有者: ID={$firstUser['id']} ({$firstUser['username']})\n";
        echo "  - 场次: {$session['title']} (ID: {$session['id']})\n";
        echo "  - 分区: {$zone['name']} (ID: {$zone['id']})\n\n";
        
        $this->transactionHistory[] = [
            'round' => 0,
            'action' => '创建',
            'seller_id' => 0,
            'buyer_id' => $firstUser['id'],
            'price' => $initialPrice,
            'user_collection_id' => $userCollectionId,
        ];
    }

    /**
     * 多次转手交易
     */
    private function repeatTransactions($rounds)
    {
        echo "📋 步骤 3: 多次转手交易（{$rounds}轮）\n";
        echo "----------------------------------------\n";
        
        // 获取当前持有者
        $currentUserCollection = Db::name('user_collection')
            ->where('item_id', $this->originalItemId)
            ->where('consignment_status', '!=', 2)
            ->order('id desc')
            ->find();
        
        if (!$currentUserCollection) {
            throw new \Exception('找不到当前持有的藏品');
        }
        
        $currentPrice = (float)$currentUserCollection['price'];
        $currentSellerId = $currentUserCollection['user_id'];
        $currentUserCollectionId = $currentUserCollection['id'];
        
        for ($round = 1; $round <= $rounds; $round++) {
            echo "\n--- 第 {$round} 轮交易 ---\n";
            
            // 选择买家（下一个用户，循环）
            $sellerIndex = array_search($currentSellerId, array_column($this->testUsers, 'id'));
            $buyerIndex = ($sellerIndex + 1) % count($this->testUsers);
            $buyer = $this->testUsers[$buyerIndex];
            
            if ($buyer['id'] == $currentSellerId) {
                // 如果只剩一个用户，跳过
                echo "⚠️  所有用户都已完成交易，停止转手\n";
                break;
            }
            
            // 计算新价格（增值4%-6%）
            $increaseRate = 0.04 + (mt_rand(0, 200) / 10000); // 4%-6%随机
            $newPrice = round($currentPrice * (1 + $increaseRate), 2);
            
            echo "卖家: ID={$currentSellerId}\n";
            echo "买家: ID={$buyer['id']} ({$buyer['username']})\n";
            echo "当前价格: {$currentPrice}元\n";
            echo "增值率: " . number_format($increaseRate * 100, 2) . "%\n";
            echo "新价格: {$newPrice}元\n";
            
            // 执行交易
            Db::startTrans();
            try {
                // 1. 创建寄售记录（简化，直接标记为已售出）
                $consignmentId = Db::name('collection_consignment')->insertGetId([
                    'user_id' => $currentSellerId,
                    'user_collection_id' => $currentUserCollectionId,
                    'item_id' => $this->originalItemId,
                    'package_id' => 0,
                    'price' => $newPrice,
                    'original_price' => $currentPrice,
                    'service_fee' => round($newPrice * 0.03, 2),
                    'coupon_used' => 0,
                    'coupon_waived' => 1,
                    'status' => 2, // 直接标记为已售出
                    'create_time' => time(),
                    'update_time' => time(),
                ]);
                
                // 2. 扣减买家余额
                $buyerUser = Db::name('user')
                    ->where('id', $buyer['id'])
                    ->lock(true)
                    ->find();
                
                $payFromBalance = min($buyerUser['balance_available'], $newPrice);
                $payFromWithdrawable = $newPrice - $payFromBalance;
                
                Db::name('user')
                    ->where('id', $buyer['id'])
                    ->update([
                        'balance_available' => $buyerUser['balance_available'] - $payFromBalance,
                        'withdrawable_money' => $buyerUser['withdrawable_money'] - $payFromWithdrawable,
                        'update_time' => time(),
                    ]);
                
                // 3. 分配卖家收益
                $item = Db::name('collection_item')->where('id', $this->originalItemId)->find();
                \app\common\service\core\FinanceService::distributeSellerIncome(
                    $currentSellerId,
                    $newPrice,
                    $currentPrice,
                    $item['title'],
                    $consignmentId
                );
                
                // 4. 创建订单
                $now = time();
                $orderNo = 'CC' . date('YmdHis') . str_pad($buyer['id'], 6, '0', STR_PAD_LEFT) . rand(1000, 9999);
                $orderId = Db::name('collection_order')->insertGetId([
                    'order_no' => $orderNo,
                    'user_id' => $buyer['id'],
                    'total_amount' => $newPrice,
                    'pay_type' => 'money',
                    'status' => 'paid',
                    'remark' => '测试转手交易|consignment_id:' . $consignmentId . '|round:' . $round,
                    'pay_time' => $now,
                    'complete_time' => $now,
                    'create_time' => $now,
                    'update_time' => $now,
                ]);
                
                Db::name('collection_order_item')->insert([
                    'order_id' => $orderId,
                    'item_id' => $this->originalItemId,
                    'item_title' => $item['title'],
                    'item_image' => $item['image'] ?? '',
                    'price' => $newPrice,
                    'quantity' => 1,
                    'subtotal' => $newPrice,
                    'product_id_record' => '转手交易',
                    'create_time' => $now,
                ]);
                
                // 5. 更新卖家藏品状态
                Db::name('user_collection')
                    ->where('id', $currentUserCollectionId)
                    ->update([
                        'consignment_status' => 2, // 已售出
                        'update_time' => $now,
                    ]);
                
                // 6. 创建买家藏品（更新价格）
                $buyerUserCollectionId = Db::name('user_collection')->insertGetId([
                    'user_id' => $buyer['id'],
                    'order_id' => $orderId,
                    'order_item_id' => 0,
                    'item_id' => $this->originalItemId,
                    'title' => $item['title'],
                    'image' => $item['image'] ?? '',
                    'price' => $newPrice, // 新价格
                    'buy_time' => $now,
                    'delivery_status' => 0,
                    'consignment_status' => 0,
                    'mining_status' => 0,
                    'create_time' => $now,
                    'update_time' => $now,
                ]);
                
                // 7. 更新藏品SPU价格（增值）
                $this->updateItemPrice($this->originalItemId, $newPrice, $currentPrice);
                
                Db::commit();
                
                echo "✓ 交易成功！订单号: {$orderNo}\n";
                
                $this->transactionHistory[] = [
                    'round' => $round,
                    'action' => '转手',
                    'seller_id' => $currentSellerId,
                    'buyer_id' => $buyer['id'],
                    'old_price' => $currentPrice,
                    'new_price' => $newPrice,
                    'increase_rate' => $increaseRate,
                    'order_id' => $orderId,
                    'user_collection_id' => $buyerUserCollectionId,
                ];
                
                // 更新当前状态
                $currentPrice = $newPrice;
                $currentSellerId = $buyer['id'];
                $currentUserCollectionId = $buyerUserCollectionId;
                
            } catch (\Exception $e) {
                Db::rollback();
                echo "❌ 第{$round}轮交易失败: " . $e->getMessage() . "\n";
                throw $e;
            }
        }
        
        echo "\n✓ 完成{$rounds}轮转手交易\n\n";
    }

    /**
     * 更新藏品价格（增值）
     */
    private function updateItemPrice($itemId, $newPrice, $oldPrice)
    {
        // 增值4%-6%随机
        $increaseRate = 0.04 + (mt_rand(0, 200) / 10000);
        $updatedPrice = round($oldPrice * (1 + $increaseRate), 2);
        
        Db::name('collection_item')
            ->where('id', $itemId)
            ->update([
                'price' => $updatedPrice,
                'update_time' => time(),
            ]);
        
        return $updatedPrice;
    }

    /**
     * 测试转矿机分红
     */
    private function testMiningDividend()
    {
        echo "📋 步骤 4: 测试转矿机分红\n";
        echo "----------------------------------------\n";
        
        // 获取当前持有者
        $currentUserCollection = Db::name('user_collection')
            ->where('item_id', $this->originalItemId)
            ->where('consignment_status', '!=', 2)
            ->where('mining_status', 0)
            ->order('id desc')
            ->find();
        
        if (!$currentUserCollection) {
            echo "⚠️  找不到可转矿机的藏品\n\n";
            return;
        }
        
        $userId = $currentUserCollection['user_id'];
        $userCollectionId = $currentUserCollection['id'];
        $currentPrice = (float)$currentUserCollection['price'];
        
        echo "当前持有者: ID={$userId}\n";
        echo "用户藏品ID: {$userCollectionId}\n";
        echo "当前价格: {$currentPrice}元\n";
        
        try {
            Db::startTrans();
            
            // 调用转矿机逻辑（模拟API: /api/collectionItem/toMining）
            
            // 如果处于寄售中，先取消寄售
            if ($currentUserCollection['consignment_status'] == 1) {
                Db::name('collection_consignment')
                    ->where('user_collection_id', $userCollectionId)
                    ->where('status', 1) // 寄售中
                    ->update([
                        'status' => 0, // 取消
                        'update_time' => time(),
                    ]);
            }
            
            // 更新用户藏品状态
            Db::name('user_collection')
                ->where('id', $userCollectionId)
                ->update([
                    'mining_status' => 1, // 转矿机
                    'mining_start_time' => time(),
                    'last_dividend_time' => 0, // 等待第一次分红
                    'consignment_status' => 0, // 确保寄售状态归零
                    'update_time' => time(),
                ]);
            
            // 如果商品已上架，下架（转为矿机后不再在商城展示）
            $item = Db::name('collection_item')
                ->where('id', $currentUserCollection['item_id'])
                ->find();
            
            if ($item && isset($item['status']) && $item['status'] == '1') {
                Db::name('collection_item')
                    ->where('id', $item['id'])
                    ->update([
                        'status' => '0',
                        'update_time' => time(),
                    ]);
            }
            
            // 记录活动日志
            Db::name('user_activity_log')->insert([
                'user_id' => $userId,
                'related_user_id' => 0,
                'action_type' => 'collection_mining',
                'change_field' => 'mining_status',
                'change_value' => '1',
                'before_value' => '0',
                'after_value' => '1',
                'remark' => '手动转为矿机',
                'extra' => json_encode([
                    'user_collection_id' => $userCollectionId,
                    'item_id' => $item['id'] ?? 0,
                    'title' => $item['title'] ?? '',
                ], JSON_UNESCAPED_UNICODE),
                'create_time' => time(),
                'update_time' => time(),
            ]);
            
            // 查询矿机分红配置
            $miningConfig = Db::name('config')
                ->where('name', 'mining_daily_dividend')
                ->value('value');
            
            $dailyDividend = $miningConfig ? (float)$miningConfig : 10.00; // 默认10元/天
            
            echo "✓ 转矿机成功！\n";
            echo "  - 每日分红: {$dailyDividend}元\n";
            echo "  - 分红将在每日定时任务中发放\n\n";
            
            Db::commit();
            
            $this->testResults['mining'] = [
                'status' => 'success',
                'user_collection_id' => $userCollectionId,
                'daily_dividend' => $dailyDividend,
                'price' => $currentPrice,
            ];
            
            // 验证矿机状态
            $verify = Db::name('user_collection')
                ->where('id', $userCollectionId)
                ->find();
            
            if ($verify['mining_status'] == 1) {
                echo "✓ 矿机状态验证通过\n\n";
            } else {
                echo "⚠️  矿机状态验证失败\n\n";
            }
            
        } catch (\Exception $e) {
            Db::rollback();
            echo "❌ 转矿机失败: " . $e->getMessage() . "\n\n";
            $this->testResults['mining'] = [
                'status' => 'failed',
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * 输出测试结果
     */
    private function printTestResults()
    {
        echo "========================================\n";
        echo "测试结果汇总\n";
        echo "========================================\n\n";
        
        echo "📊 交易历史:\n";
        echo "----------------------------------------\n";
        
        $initialPrice = $this->transactionHistory[0]['price'] ?? 0;
        $finalPrice = 0;
        
        foreach ($this->transactionHistory as $idx => $transaction) {
            if ($idx == 0) {
                echo sprintf(
                    "%d. [%s] 创建 → 用户ID=%d, 价格=%.2f元\n",
                    $transaction['round'],
                    $transaction['action'],
                    $transaction['buyer_id'],
                    $transaction['price']
                );
            } else {
                $increase = $transaction['new_price'] - $transaction['old_price'];
                $rate = $transaction['increase_rate'] ?? 0;
                echo sprintf(
                    "%d. [%s] 用户ID=%d → 用户ID=%d, %.2f元 → %.2f元 (+%.2f元, +%.2f%%)\n",
                    $transaction['round'],
                    $transaction['action'],
                    $transaction['seller_id'],
                    $transaction['buyer_id'],
                    $transaction['old_price'],
                    $transaction['new_price'],
                    $increase,
                    $rate * 100
                );
                $finalPrice = $transaction['new_price'];
            }
        }
        
        if ($finalPrice > 0 && $initialPrice > 0) {
            $totalIncrease = $finalPrice - $initialPrice;
            $totalRate = (($finalPrice / $initialPrice) - 1) * 100;
            echo "\n总增值: {$initialPrice}元 → {$finalPrice}元 (+{$totalIncrease}元, +{$totalRate}%)\n";
        }
        
        echo "\n";
        
        if (isset($this->testResults['mining'])) {
            $mining = $this->testResults['mining'];
            echo "📊 矿机分红:\n";
            echo "----------------------------------------\n";
            if ($mining['status'] == 'success') {
                echo "✓ 转矿机成功\n";
                echo "  - 用户藏品ID: {$mining['user_collection_id']}\n";
                echo "  - 当前价格: {$mining['price']}元\n";
                echo "  - 每日分红: {$mining['daily_dividend']}元\n";
            } else {
                echo "❌ 转矿机失败: {$mining['error']}\n";
            }
        }
        
        echo "\n========================================\n";
    }
}

// 获取命令行参数
$startUserId = isset($argv[1]) ? (int)$argv[1] : null;
$rounds = isset($argv[2]) ? (int)$argv[2] : 5;

// 执行测试
$test = new CollectionRepeatSaleTest();
$test->runTest($startUserId, $rounds);

