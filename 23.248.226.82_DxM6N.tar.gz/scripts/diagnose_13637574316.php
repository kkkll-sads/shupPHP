<?php
/**
 * 诊断用户 13637574316 的寄售问题
 * 资产: 37-DATA-0040-0332
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$mobile = '13637574316';
$assetCode = '37-DATA-0040-0332';

echo "正在诊断用户: {$mobile} 资产: {$assetCode} ...\n";

// 1. 用户信息
$user = Db::name('user')->where('mobile', $mobile)->find();
if (!$user) {
    echo "用户不存在!\n";
    exit;
}
echo "User ID: {$user['id']}, Name: {$user['username']}\n";
$userId = $user['id'];

// 2. 资产信息 (Item)
$item = Db::name('collection_item')->where('asset_code', $assetCode)->find();
if (!$item) {
    echo "Item (Asset Code: {$assetCode}) 不存在!\n"; 
    // Maybe search by title if code is part of title? But format looks like asset_code.
} else {
    echo "Item ID: {$item['id']}, Title: {$item['title']}, Price: {$item['price']}, Zone: {$item['zone_id']}, Session: {$item['session_id']}, PriceZone: '{$item['price_zone']}'\n";
    
    // 3. 用户持仓 (User Collection)
    $collection = Db::name('user_collection')
        ->where('user_id', $userId)
        ->where('item_id', $item['id'])
        ->find();
        
    if ($collection) {
        echo "用户持仓 ID: {$collection['id']}, Consignment Status: {$collection['consignment_status']} (0=None, 1=Selling)\n";
    } else {
        echo "[WARNING] 用户名下未找到该资产!\n";
    }
    
    // 4. 寄售记录 (Consignment History)
    echo "\n--- 寄售记录 (Last 5) ---\n";
    $history = Db::name('collection_consignment')
        ->where('user_id', $userId)
        #->where('item_id', $item['id']) // Check all consignments or just this item? Check this item first.
        ->where('item_id', $item['id'])
        ->order('id', 'desc')
        ->limit(5)
        ->select();
        
    if ($history->isEmpty()) {
        echo "无该资产的寄售记录。\n";
    } else {
        foreach($history as $h) {
            echo "ID: {$h['id']}, Status: {$h['status']}, CouponID: {$h['coupon_id']}, Time: " . date('Y-m-d H:i:s', $h['create_time']) . "\n";
            // Check Coupon Status
            if ($h['coupon_id']) {
                $cp = Db::name('user_consignment_coupon')->find($h['coupon_id']);
                $cpStatus = $cp ? $cp['status'] : 'NULL';
                echo "  -> Coupon {$h['coupon_id']} Status: {$cpStatus} (0=Used, 1=Unused)\n";
            }
        }
    }
}

// 5. 检查丢失的卷? (Look for used coupons without successful consignment)
echo "\n--- 最近使用的卷 (Last 10) ---\n";
// Coupon update_time recent?
$recentCoupons = Db::name('user_consignment_coupon')
    ->where('user_id', $userId)
    ->where('status', 0) // Used
    ->order('update_time', 'desc')
    ->limit(10)
    ->select();

foreach ($recentCoupons as $rc) {
    echo "Coupon ID: {$rc['id']}, Zone: {$rc['zone_id']}, Session: {$rc['session_id']}, UpdateTime: " . date('Y-m-d H:i:s', $rc['update_time']) . "\n";
}
    
// 6. 检查可用卷 (Available Coupons)
echo "\n--- 可用卷 (First 5) ---\n";
$avail = Db::name('user_consignment_coupon')
    ->where('user_id', $userId)
    ->where('status', 1) // Unused
    ->limit(5)
    ->select();

if ($avail->isEmpty()) {
    echo "用户没有可用卷!\n";
} else {
    foreach($avail as $a) {
        echo "ID: {$a['id']}, Zone: {$a['zone_id']}, PriceZone: {$a['price_zone']}, Session: {$a['session_id']}\n";
    }
}

// Check if recent items are similar
echo "\n--- 最近已寄售的物品 ---\n";
$itemIds = [4666, 4661, 4651, 4376];
$items = Db::name('collection_item')->whereIn('id', $itemIds)->select();
foreach($items as $i) {
    echo "Item ID: {$i['id']}, Code: {$i['asset_code']}, Title: {$i['title']}\n";
}
