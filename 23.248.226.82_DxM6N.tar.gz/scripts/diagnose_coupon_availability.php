<?php
/**
 * 诊断用户寄售卷可用性问题
 * 用法: php scripts/diagnose_coupon_availability.php <mobile>
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$mobile = isset($argv[1]) ? $argv[1] : '13256601234';

echo "正在诊断用户: {$mobile}\n";

// 1. 获取用户信息
$user = Db::name('user')->where('mobile', $mobile)->find();
if (!$user) {
    echo "未找到用户!\n";
    exit;
}

$userId = $user['id'];
echo "用户ID: {$userId}, 用户名: {$user['username']}\n";

// 2. 检查用户的寄售卷
echo "\n--- 用户持有的寄售卷 (Status 1 = Unused) ---\n";
// 注意：Status 1 是未使用，Status 0 是已使用（根据之前的分析）
$coupons = Db::name('user_consignment_coupon')
    ->where('user_id', $userId)
    ->where('status', 1) 
    ->select();

$count = count($coupons);
echo "持有未使用寄售卷数量: {$count}\n";

if ($count == 0) {
    echo "没有可用的寄售卷。\n";
} else {
    foreach ($coupons as $cp) {
        echo "ID: {$cp['id']}, ZoneID: {$cp['zone_id']}, SessionID: {$cp['session_id']}, PriceZone: {$cp['price_zone']}, ExpireTime: " . date('Y-m-d H:i:s', $cp['expire_time']) . "\n";
    }
}

// 3. 检查用户的实际资产
echo "\n--- 用户当前持有的资产 (ba_user_collection) ---\n";
$assets = Db::name('user_collection')
    ->alias('uc')
    ->join('collection_item ci', 'uc.item_id = ci.id', 'LEFT')
    ->where('uc.user_id', $userId)
    ->where('uc.consignment_status', 0) // 0=未寄售
    ->field('uc.id as asset_id, uc.item_id, ci.title, ci.price, ci.price_zone, ci.zone_id')
    ->select();

foreach ($assets as $asset) {
    echo "Asset ID: {$asset['asset_id']}, Title: {$asset['title']}, Price: {$asset['price']}, ZoneID: {$asset['zone_id']}, PriceZone: {$asset['price_zone']}\n";
    
    // Check against Coupon 1954
    $coupon = [
        'id' => 1954,
        'zone_id' => 10,
        'session_id' => 2,
        'price_zone' => '3000'
    ];
    
    $zoneMatch = ($coupon['zone_id'] == 0 || $coupon['zone_id'] == $asset['zone_id']) ? "YES" : "NO";
    echo "  -> Match Coupon 1954 (Zone 10)? ZoneMatch: $zoneMatch (Asset Zone: {$asset['zone_id']})\n";
}

