<?php
/**
 * 核心功能测试脚本
 * 测试寄售购买撮合、旧资产解锁等核心功能
 * 
 * 使用方法:
 * php scripts/test_core_features.php
 */

require __DIR__ . '/../vendor/autoload.php';

$app = new think\App();
$app->initialize();

use think\facade\Db;

// 辅助函数
if (!function_exists('hash_password')) {
    function hash_password($password) {
        return md5($password . 'think');
    }
}

if (!function_exists('generateSJSFlowNo')) {
    function generateSJSFlowNo($userId) {
        return 'SJS' . date('YmdHis') . str_pad((string)$userId, 6, '0', STR_PAD_LEFT) . rand(100, 999);
    }
}

if (!function_exists('generateBatchNo')) {
    function generateBatchNo($prefix, $id) {
        return $prefix . '_' . date('Ymd') . '_' . str_pad((string)$id, 8, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('generateFlowNo')) {
    function generateFlowNo() {
        return 'FL' . date('YmdHis') . rand(100000, 999999);
    }
}

class CoreFeaturesTest
{
    private $testUsers = [];
    private $testResults = [];
    private $testConsignmentId = 0;
    private $testUserCollectionId = 0;

    public function __construct()
    {
        echo "========================================\n";
        echo "核心功能测试脚本\n";
        echo "========================================\n\n";
    }

    /**
     * 运行所有测试
     */
    public function runAllTests()
    {
        try {
            // 1. 准备测试数据
            $this->prepareTestData();
            
            // 2. 测试旧资产解锁
            $this->testOldAssetUnlock();
            
            // 3. 测试寄售创建
            $this->testConsignmentCreate();
            
            // 4. 测试寄售购买
            $this->testConsignmentPurchase();
            
            // 5. 输出测试结果
            $this->printTestResults();
            
        } catch (\Exception $e) {
            echo "❌ 测试执行失败: " . $e->getMessage() . "\n";
            echo $e->getTraceAsString() . "\n";
        }
    }

    /**
     * 准备测试数据
     */
    private function prepareTestData()
    {
        echo "📋 步骤 1: 准备测试数据\n";
        echo "----------------------------------------\n";
        
        // 使用已存在的测试用户（ID 176-180）
        $existingUsers = Db::name('user')
            ->where('id', 'in', [176, 177, 178, 179, 180])
            ->field('id, username, mobile, balance_available, pending_activation_gold, user_type')
            ->select()
            ->toArray();
        
        if (count($existingUsers) < 3) {
            throw new \Exception('测试用户不足，请先运行批量注册脚本');
        }
        
        $this->testUsers = [
            'seller' => $existingUsers[0],      // 卖家
            'buyer' => $existingUsers[1],       // 买家
            'unlock_user' => $existingUsers[2], // 解锁测试用户
        ];
        
        echo "✓ 卖家用户: ID={$this->testUsers['seller']['id']}, 用户名={$this->testUsers['seller']['username']}\n";
        echo "✓ 买家用户: ID={$this->testUsers['buyer']['id']}, 用户名={$this->testUsers['buyer']['username']}\n";
        echo "✓ 解锁用户: ID={$this->testUsers['unlock_user']['id']}, 用户名={$this->testUsers['unlock_user']['username']}\n";
        
        // 确保买家有足够余额
        if ($this->testUsers['buyer']['balance_available'] < 5000) {
            Db::name('user')
                ->where('id', $this->testUsers['buyer']['id'])
                ->update([
                    'balance_available' => 5000,
                    'money' => 5000,
                    'update_time' => time(),
                ]);
            echo "✓ 已为买家添加余额: 5000元\n";
        }
        
        // 确保解锁用户有足够待激活金和交易用户身份
        Db::name('user')
            ->where('id', $this->testUsers['unlock_user']['id'])
            ->update([
                'pending_activation_gold' => 3000,
                'user_type' => 2, // 交易用户
                'update_time' => time(),
            ]);
        echo "✓ 已为解锁用户设置: 待激活金3000元, 用户类型=交易用户\n";
        
        echo "\n";
    }

    /**
     * 测试旧资产解锁
     */
    private function testOldAssetUnlock()
    {
        echo "📋 步骤 2: 测试旧资产解锁\n";
        echo "----------------------------------------\n";
        
        $userId = $this->testUsers['unlock_user']['id'];
        
        try {
            // 1. 检查解锁条件
            $user = Db::name('user')
                ->where('id', $userId)
                ->field('pending_activation_gold, user_type, old_assets_unlock_count')
                ->find();
            
            echo "用户信息: 待激活金={$user['pending_activation_gold']}, 用户类型={$user['user_type']}, 已解锁次数={$user['old_assets_unlock_count']}\n";
            
            // 需要至少3个直推交易用户才能解锁，先模拟创建直推用户
            // 这里简化处理，直接测试解锁流程（假设条件已满足）
            
            // 2. 模拟解锁流程（直接调用服务）
            $requiredGold = 1000.00;
            
            if ($user['pending_activation_gold'] < $requiredGold) {
                echo "⚠️  待激活金不足，跳过解锁测试\n";
                $this->testResults['old_asset_unlock'] = [
                    'status' => 'skipped',
                    'message' => '待激活金不足',
                ];
                echo "\n";
                return;
            }
            
            // 调用解锁服务
            $unlockCount = (int)($user['old_assets_unlock_count'] ?? 0) + 1;
            $result = \app\common\service\LegacyAssetService::executeUnlock($userId, $requiredGold, $unlockCount);
            
            // 扣除待激活金
            Db::name('user')
                ->where('id', $userId)
                ->update([
                    'old_assets_status' => 1,
                    'old_assets_unlock_count' => $unlockCount,
                    'pending_activation_gold' => Db::raw('pending_activation_gold - ' . $requiredGold),
                    'update_time' => time(),
                ]);
            
            // 创建解锁记录
            Db::name('user_old_assets_unlock')->insert([
                'user_id' => $userId,
                'unlock_count' => $unlockCount,
                'unlock_status' => 1,
                'unlock_time' => time(),
                'consumed_gold' => $requiredGold,
                'reward_equity_package' => 1000.00,
                'reward_consignment_coupon' => 1,
                'unlock_conditions' => json_encode(['test' => true]),
                'create_time' => time(),
            ]);
            
            // 检查解锁后的用户藏品
            $userCollections = Db::name('user_collection')
                ->where('user_id', $userId)
                ->where('create_time', '>', time() - 60)
                ->select()
                ->toArray();
            
            echo "✓ 解锁成功！\n";
            echo "  - 消耗待激活金: {$requiredGold}元\n";
            echo "  - 解锁次数: {$unlockCount}\n";
            echo "  - 新增藏品数: " . count($userCollections) . "\n";
            
            if (!empty($userCollections)) {
                foreach ($userCollections as $uc) {
                    echo "  - 藏品: {$uc['title']} (ID: {$uc['id']})\n";
                }
            }
            
            $this->testResults['old_asset_unlock'] = [
                'status' => 'success',
                'unlock_count' => $unlockCount,
                'collections_created' => count($userCollections),
            ];
            
        } catch (\Exception $e) {
            echo "❌ 解锁测试失败: " . $e->getMessage() . "\n";
            $this->testResults['old_asset_unlock'] = [
                'status' => 'failed',
                'error' => $e->getMessage(),
            ];
        }
        
        echo "\n";
    }

    /**
     * 测试寄售创建
     */
    private function testConsignmentCreate()
    {
        echo "📋 步骤 3: 测试寄售创建\n";
        echo "----------------------------------------\n";
        
        $sellerId = $this->testUsers['seller']['id'];
        
        try {
            // 1. 查找卖家已有的藏品（如果没有，创建一个测试藏品）
            $userCollection = Db::name('user_collection')
                ->where('user_id', $sellerId)
                ->where('consignment_status', 0)
                ->where('mining_status', 0) // 不在矿机状态
                ->order('id desc')
                ->find();
            
            if (!$userCollection) {
                // 创建测试藏品
                $item = $this->createTestCollectionItem();
                $userCollection = $this->createTestUserCollection($sellerId, $item['id'], $item['price']);
                echo "✓ 创建测试藏品: {$item['title']} (用户藏品ID: {$userCollection['id']})\n";
            } else {
                echo "✓ 使用已有藏品: {$userCollection['title']} (用户藏品ID: {$userCollection['id']})\n";
            }
            
            $userCollectionId = $userCollection['id'];
            $itemId = $userCollection['item_id'];
            $itemPrice = (float)$userCollection['price'];
            $consignmentPrice = $itemPrice * 1.1; // 寄售价格为原价的110%
            
            // 2. 检查场次
            $item = Db::name('collection_item')->where('id', $itemId)->find();
            $sessionId = (int)($item['session_id'] ?? 0);
            
            if ($sessionId <= 0) {
                // 查找一个启用的场次
                $session = Db::name('collection_session')
                    ->where('status', '1')
                    ->order('id desc')
                    ->find();
                if ($session) {
                    $sessionId = $session['id'];
                } else {
                    throw new \Exception('没有可用的交易场次');
                }
            }
            
            // 3. 检查用户余额和服务费
            $user = Db::name('user')
                ->where('id', $sellerId)
                ->field('service_fee_balance, consignment_coupon')
                ->find();
            
            $serviceFeeRate = 0.03; // 3%
            $serviceFee = round($consignmentPrice * $serviceFeeRate, 2);
            
            if ($user['service_fee_balance'] < $serviceFee) {
                // 添加确权金
                Db::name('user')
                    ->where('id', $sellerId)
                    ->update([
                        'service_fee_balance' => $serviceFee * 2,
                        'update_time' => time(),
                    ]);
                echo "✓ 已为用户添加确权金: " . ($serviceFee * 2) . "元\n";
            }
            
            // 4. 创建寄售记录（简化流程，直接插入数据库）
            $now = time();
            $consignmentId = Db::name('collection_consignment')->insertGetId([
                'user_id' => $sellerId,
                'user_collection_id' => $userCollectionId,
                'item_id' => $itemId,
                'package_id' => 0,
                'price' => $consignmentPrice,
                'original_price' => $itemPrice,
                'service_fee' => $serviceFee,
                'coupon_used' => 0,
                'coupon_waived' => 1, // 测试时豁免券
                'status' => 1, // 寄售中
                'create_time' => $now,
                'update_time' => $now,
            ]);
            
            // 更新用户藏品状态
            Db::name('user_collection')
                ->where('id', $userCollectionId)
                ->update([
                    'consignment_status' => 1, // 寄售中
                    'update_time' => $now,
                ]);
            
            echo "✓ 寄售创建成功！\n";
            echo "  - 寄售ID: {$consignmentId}\n";
            echo "  - 寄售价格: {$consignmentPrice}元\n";
            echo "  - 服务费: {$serviceFee}元\n";
            echo "  - 场次ID: {$sessionId}\n";
            
            $this->testResults['consignment_create'] = [
                'status' => 'success',
                'consignment_id' => $consignmentId,
                'price' => $consignmentPrice,
            ];
            
            // 保存寄售ID供后续测试使用
            $this->testConsignmentId = $consignmentId;
            $this->testUserCollectionId = $userCollectionId;
            
        } catch (\Exception $e) {
            echo "❌ 寄售创建测试失败: " . $e->getMessage() . "\n";
            $this->testResults['consignment_create'] = [
                'status' => 'failed',
                'error' => $e->getMessage(),
            ];
        }
        
        echo "\n";
    }

    /**
     * 测试寄售购买
     */
    private function testConsignmentPurchase()
    {
        echo "📋 步骤 4: 测试寄售购买\n";
        echo "----------------------------------------\n";
        
        if (empty($this->testConsignmentId)) {
            echo "⚠️  没有可用的寄售记录，跳过购买测试\n";
            $this->testResults['consignment_purchase'] = [
                'status' => 'skipped',
                'message' => '没有寄售记录',
            ];
            echo "\n";
            return;
        }
        
        $buyerId = $this->testUsers['buyer']['id'];
        $consignmentId = $this->testConsignmentId;
        
        try {
            // 1. 查询寄售记录
            $consignment = Db::name('collection_consignment')
                ->where('id', $consignmentId)
                ->find();
            
            if (!$consignment || $consignment['status'] != 1) {
                throw new \Exception('寄售记录不存在或状态不正确');
            }
            
            $sellerId = (int)$consignment['user_id'];
            $consignmentPrice = (float)$consignment['price'];
            
            if ($sellerId == $buyerId) {
                throw new \Exception('不能购买自己寄售的藏品');
            }
            
            echo "寄售信息: ID={$consignmentId}, 价格={$consignmentPrice}元, 卖家ID={$sellerId}\n";
            
            // 2. 检查买家余额
            $buyer = Db::name('user')
                ->where('id', $buyerId)
                ->field('balance_available, withdrawable_money')
                ->find();
            
            $totalBalance = $buyer['balance_available'] + $buyer['withdrawable_money'];
            if ($totalBalance < $consignmentPrice) {
                // 添加余额
                Db::name('user')
                    ->where('id', $buyerId)
                    ->update([
                        'balance_available' => $consignmentPrice + 1000,
                        'money' => $consignmentPrice + 1000,
                        'update_time' => time(),
                    ]);
                echo "✓ 已为买家添加余额: " . ($consignmentPrice + 1000) . "元\n";
            }
            
            // 3. 调用购买流程（简化版，直接操作数据库）
            Db::startTrans();
            try {
                // 锁定寄售记录
                $consignment = Db::name('collection_consignment')
                    ->where('id', $consignmentId)
                    ->lock(true)
                    ->find();
                
                // 锁定买家和卖家
                $buyer = Db::name('user')
                    ->where('id', $buyerId)
                    ->lock(true)
                    ->find();
                $seller = Db::name('user')
                    ->where('id', $sellerId)
                    ->lock(true)
                    ->find();
                
                // 扣除买家余额
                $payFromBalance = min($buyer['balance_available'], $consignmentPrice);
                $payFromWithdrawable = $consignmentPrice - $payFromBalance;
                
                Db::name('user')
                    ->where('id', $buyerId)
                    ->update([
                        'balance_available' => $buyer['balance_available'] - $payFromBalance,
                        'withdrawable_money' => $buyer['withdrawable_money'] - $payFromWithdrawable,
                        'update_time' => time(),
                    ]);
                
                // 调用结算服务分配卖家收益
                $item = Db::name('collection_item')->where('id', $consignment['item_id'])->find();
                \app\common\service\core\FinanceService::distributeSellerIncome(
                    $sellerId,
                    $consignmentPrice,
                    $consignment['original_price'],
                    $item['title'],
                    $consignmentId
                );
                
                // 创建订单
                $now = time();
                $orderNo = 'CC' . date('YmdHis') . str_pad($buyerId, 6, '0', STR_PAD_LEFT) . rand(1000, 9999);
                $orderId = Db::name('collection_order')->insertGetId([
                    'order_no' => $orderNo,
                    'user_id' => $buyerId,
                    'total_amount' => $consignmentPrice,
                    'pay_type' => 'money',
                    'status' => 'paid',
                    'remark' => '测试寄售购买|consignment_id:' . $consignmentId,
                    'pay_time' => $now,
                    'complete_time' => $now,
                    'create_time' => $now,
                    'update_time' => $now,
                ]);
                
                Db::name('collection_order_item')->insert([
                    'order_id' => $orderId,
                    'item_id' => $consignment['item_id'],
                    'item_title' => $item['title'],
                    'item_image' => $item['image'] ?? '',
                    'price' => $consignmentPrice,
                    'quantity' => 1,
                    'subtotal' => $consignmentPrice,
                    'product_id_record' => '寄售购买',
                    'create_time' => $now,
                ]);
                
                // 更新寄售记录
                Db::name('collection_consignment')
                    ->where('id', $consignmentId)
                    ->update([
                        'status' => 2, // 已售出
                        'update_time' => $now,
                    ]);
                
                // 更新卖家藏品状态
                Db::name('user_collection')
                    ->where('id', $consignment['user_collection_id'])
                    ->update([
                        'consignment_status' => 2, // 已售出
                        'update_time' => $now,
                    ]);
                
                // 创建买家藏品
                $buyerCollectionId = Db::name('user_collection')->insertGetId([
                    'user_id' => $buyerId,
                    'order_id' => $orderId,
                    'order_item_id' => 0,
                    'item_id' => $consignment['item_id'],
                    'title' => $item['title'],
                    'image' => $item['image'] ?? '',
                    'price' => $consignmentPrice,
                    'buy_time' => $now,
                    'delivery_status' => 0,
                    'consignment_status' => 0,
                    'create_time' => $now,
                    'update_time' => $now,
                ]);
                
                Db::commit();
                
                echo "✓ 购买成功！\n";
                echo "  - 订单号: {$orderNo}\n";
                echo "  - 订单ID: {$orderId}\n";
                echo "  - 买家藏品ID: {$buyerCollectionId}\n";
                echo "  - 支付金额: {$consignmentPrice}元\n";
                
                $this->testResults['consignment_purchase'] = [
                    'status' => 'success',
                    'order_id' => $orderId,
                    'order_no' => $orderNo,
                    'buyer_collection_id' => $buyerCollectionId,
                ];
                
            } catch (\Exception $e) {
                Db::rollback();
                throw $e;
            }
            
        } catch (\Exception $e) {
            echo "❌ 寄售购买测试失败: " . $e->getMessage() . "\n";
            $this->testResults['consignment_purchase'] = [
                'status' => 'failed',
                'error' => $e->getMessage(),
            ];
        }
        
        echo "\n";
    }

    /**
     * 创建测试藏品
     */
    private function createTestCollectionItem()
    {
        $session = Db::name('collection_session')
            ->where('status', '1')
            ->order('id desc')
            ->find();
        
        if (!$session) {
            throw new \Exception('没有可用的交易场次');
        }
        
        $now = time();
        $itemId = Db::name('collection_item')->insertGetId([
            'title' => '测试藏品-' . date('YmdHis'),
            'image' => '',
            'price' => 1000.00,
            'session_id' => $session['id'],
            'zone_id' => 0,
            'stock' => 0,
            'status' => '1',
            'create_time' => $now,
            'update_time' => $now,
        ]);
        
        return Db::name('collection_item')->where('id', $itemId)->find();
    }

    /**
     * 创建测试用户藏品
     */
    private function createTestUserCollection($userId, $itemId, $price)
    {
        $item = Db::name('collection_item')->where('id', $itemId)->find();
        $now = time();
        
        $userCollectionId = Db::name('user_collection')->insertGetId([
            'user_id' => $userId,
            'order_id' => 0,
            'order_item_id' => 0,
            'item_id' => $itemId,
            'title' => $item['title'],
            'image' => $item['image'] ?? '',
            'price' => $price,
            'buy_time' => $now,
            'delivery_status' => 0,
            'consignment_status' => 0,
            'mining_status' => 0,
            'create_time' => $now,
            'update_time' => $now,
        ]);
        
        return Db::name('user_collection')->where('id', $userCollectionId)->find();
    }

    /**
     * 输出测试结果
     */
    private function printTestResults()
    {
        echo "========================================\n";
        echo "测试结果汇总\n";
        echo "========================================\n\n";
        
        foreach ($this->testResults as $testName => $result) {
            $status = $result['status'];
            $icon = $status == 'success' ? '✓' : ($status == 'skipped' ? '⚠️ ' : '❌');
            echo "{$icon} {$testName}: {$status}\n";
            
            if ($status == 'success') {
                foreach ($result as $key => $value) {
                    if ($key != 'status') {
                        echo "   - {$key}: {$value}\n";
                    }
                }
            } elseif ($status == 'failed') {
                echo "   - 错误: {$result['error']}\n";
            }
            echo "\n";
        }
        
        echo "========================================\n";
    }
}

// 执行测试
$test = new CoreFeaturesTest();
$test->runAllTests();

