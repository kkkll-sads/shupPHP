<?php
/**
 * 查看今天的增值记录并诊断问题
 */

require dirname(__DIR__) . '/vendor/autoload.php';

$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n=== 增值和撮合诊断 ===\n\n";

// 1. 查看今天的增值记录
$logs = \think\facade\Db::name('collection_appreciation_log')
    ->whereTime('create_time', 'today')
    ->order('create_time desc')
    ->select()
    ->toArray();

echo "今天增值记录总数: " . count($logs) . "\n\n";

if (!empty($logs)) {
    echo "增值明细:\n";
    foreach ($logs as $log) {
        echo sprintf("%s | 藏品%d | %.2f -> %.2f\n",
            date('H:i:s', $log['create_time']),
            $log['item_id'],
            $log['before_price'],
            $log['after_price']
        );
    }
} else {
    echo "**今天没有增值记录！**\n";
}

echo "\n=== 结论 ===\n";
echo "1. 370个待撮合预约都是今天11:43-11:58创建的\n";
echo "2. 12:11撮合失败，所有370单处理失败\n";
echo "3. 日志权限已修复\n";

if (empty($logs)) {
    echo "4. **没有增值发生** - 撮合失败所以价格没有增值\n";
    echo "\n解决方案：直接重新运行撮合命令即可\n";
} else {
    echo "4. **已有增值发生** - 需要避免重复增值\n";
    echo "\n解决方案：重新运行撮合，系统会检查避免重复增值\n";
}

echo "\n";
