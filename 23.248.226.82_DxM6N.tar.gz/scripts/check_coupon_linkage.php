<?php
/**
 * 检查 Coupon 1884, 1878 的去向
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$couponIds = [1884, 1878, 1873, 1861];

echo "正在追踪 coupons: " . implode(',', $couponIds) . " ...\n";

foreach ($couponIds as $cid) {
    echo "\n--- Coupon {$cid} ---\n";
    $consignment = Db::name('collection_consignment')->where('coupon_id', $cid)->find();
    
    if ($consignment) {
        echo "关联 consignment ID: {$consignment['id']}\n";
        echo "Item ID: {$consignment['item_id']} (Status: {$consignment['status']})\n";
        echo "Time: " . date('Y-m-d H:i:s', $consignment['create_time']) . "\n";
    } else {
        echo "[WARNING] 未找到关联的 Consignment 记录! (Coupon Used but no Record)\n";
    }
}
