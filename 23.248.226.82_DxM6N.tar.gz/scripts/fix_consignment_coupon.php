<?php
/**
 * 修复用户寄售卷问题
 * 恢复寄售卷 1751 为未使用状态
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$couponId = 1751;
$userId = 643; // m18510253801

echo "正在修复寄售卷 ID: {$couponId} ...\n";

$coupon = Db::name('user_consignment_coupon')->where('id', $couponId)->find();

if (!$coupon) {
    echo "寄售卷不存在!\n";
    exit;
}

if ($coupon['status'] == 1) {
    echo "寄售卷当前状态已经是 1 (未使用)，无需修复。\n";
    exit;
}

echo "当前状态: {$coupon['status']} (应为 1)\n";
echo "更新时间: " . date('Y-m-d H:i:s', $coupon['update_time']) . "\n";

// 执行修复
Db::name('user_consignment_coupon')
    ->where('id', $couponId)
    ->update([
        'status' => 1,
        'update_time' => time()
    ]);

echo "修复完成! 状态已更正为 1。\n";
