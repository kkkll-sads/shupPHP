<?php
/**
 * 用户寄售成功率分析
 * 统计寄售成交率、流拍率、平均成交时间等
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

// 初始化应用
$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n";
echo "===========================================\n";
echo "      用户寄售成功率分析\n";
echo "===========================================\n";
echo "检查时间: " . date('Y-m-d H:i:s') . "\n";
echo "-------------------------------------------\n\n";

// ========================================
// 1. 整体寄售统计
// ========================================
echo "📊 【整体寄售统计】\n";
echo "-------------------------------------------\n";

// 查询所有寄售记录
$consignments = Db::name('collection_consignment')
    ->select()
    ->toArray();

$statusStats = [
    0 => ['name' => '已取消', 'count' => 0],
    1 => ['name' => '寄售中', 'count' => 0],
    2 => ['name' => '已售出', 'count' => 0],
    3 => ['name' => '已下架/流拍', 'count' => 0],
];

$totalValue = 0;
$soldValue = 0;
$byUser = [];
$soldTimes = []; // 成交时间（小时）

foreach ($consignments as $consign) {
    $status = (int)$consign['status'];
    $price = (float)$consign['price'];
    $userId = (int)$consign['user_id'];
    
    if (isset($statusStats[$status])) {
        $statusStats[$status]['count']++;
    }
    
    $totalValue += $price;
    
    if ($status === 2) { // 已售出
        $soldValue += $price;
        
        // 计算成交时间
        $createTime = (int)$consign['create_time'];
        $soldTime = (int)($consign['sold_time'] ?? $consign['update_time']);
        $duration = ($soldTime - $createTime) / 3600; // 转换为小时
        $soldTimes[] = $duration;
    }
    
    // 按用户统计
    if (!isset($byUser[$userId])) {
        $byUser[$userId] = [
            'total' => 0,
            'selling' => 0,
            'sold' => 0,
            'failed' => 0,
            'cancelled' => 0,
            'total_value' => 0,
            'sold_value' => 0,
        ];
    }
    
    $byUser[$userId]['total']++;
    $byUser[$userId]['total_value'] += $price;
    
    switch ($status) {
        case 0: $byUser[$userId]['cancelled']++; break;
        case 1: $byUser[$userId]['selling']++; break;
        case 2: 
            $byUser[$userId]['sold']++; 
            $byUser[$userId]['sold_value'] += $price;
            break;
        case 3: $byUser[$userId]['failed']++; break;
    }
}

$totalCount = count($consignments);
$soldCount = $statusStats[2]['count'];
$failedCount = $statusStats[3]['count'];
$sellingCount = $statusStats[1]['count'];
$cancelledCount = $statusStats[0]['count'];

// 计算成功率（已售出 / (已售出 + 流拍)）
$completedCount = $soldCount + $failedCount;
$successRate = $completedCount > 0 ? round($soldCount / $completedCount * 100, 2) : 0;

// 整体流拍率
$failRate = $completedCount > 0 ? round($failedCount / $completedCount * 100, 2) : 0;

echo "寄售总记录: {$totalCount} 条\n\n";

foreach ($statusStats as $status => $data) {
    $percentage = $totalCount > 0 ? round($data['count'] / $totalCount * 100, 1) : 0;
    echo sprintf("%-15s: %5d 条 (%5.1f%%)\n", 
        $data['name'], 
        $data['count'],
        $percentage
    );
}

echo "\n";
echo "寄售总价值: " . number_format($totalValue, 2) . " 元\n";
echo "成交总金额: " . number_format($soldValue, 2) . " 元\n";
echo "\n";
echo "🎯 成功率: {$successRate}% (已售出 / 已完成)\n";
echo "❌ 流拍率: {$failRate}%\n";
echo "⏳ 进行中: {$sellingCount} 单\n";

// ========================================
// 2. 成交时间分析
// ========================================
if (!empty($soldTimes)) {
    echo "\n📊 【成交时间分析】\n";
    echo "-------------------------------------------\n";
    
    $avgTime = array_sum($soldTimes) / count($soldTimes);
    $minTime = min($soldTimes);
    $maxTime = max($soldTimes);
    
    // 中位数
    sort($soldTimes);
    $mid = floor(count($soldTimes) / 2);
    $medianTime = count($soldTimes) % 2 == 0 
        ? ($soldTimes[$mid - 1] + $soldTimes[$mid]) / 2 
        : $soldTimes[$mid];
    
    echo "成交记录数: " . count($soldTimes) . " 条\n";
    echo "平均成交时间: " . number_format($avgTime, 2) . " 小时 (" . number_format($avgTime / 24, 1) . " 天)\n";
    echo "中位成交时间: " . number_format($medianTime, 2) . " 小时 (" . number_format($medianTime / 24, 1) . " 天)\n";
    echo "最快成交: " . number_format($minTime, 2) . " 小时\n";
    echo "最慢成交: " . number_format($maxTime, 2) . " 小时 (" . number_format($maxTime / 24, 1) . " 天)\n";
    
    // 时间分布
    $timeRanges = [
        '1小时内' => 0,
        '1-6小时' => 0,
        '6-24小时' => 0,
        '1-3天' => 0,
        '3-7天' => 0,
        '7天以上' => 0,
    ];
    
    foreach ($soldTimes as $time) {
        if ($time < 1) $timeRanges['1小时内']++;
        elseif ($time < 6) $timeRanges['1-6小时']++;
        elseif ($time < 24) $timeRanges['6-24小时']++;
        elseif ($time < 72) $timeRanges['1-3天']++;
        elseif ($time < 168) $timeRanges['3-7天']++;
        else $timeRanges['7天以上']++;
    }
    
    echo "\n成交时间分布:\n";
    foreach ($timeRanges as $range => $count) {
        $pct = round($count / count($soldTimes) * 100, 1);
        echo sprintf("  %-15s: %5d 条 (%5.1f%%)\n", $range, $count, $pct);
    }
}

// ========================================
// 3. 按场次统计
// ========================================
echo "\n📊 【按场次统计】\n";
echo "-------------------------------------------\n";

$bySession = [];
foreach ($consignments as $consign) {
    $sessionId = (int)($consign['session_id'] ?? 0);
    
    if (!isset($bySession[$sessionId])) {
        $bySession[$sessionId] = [
            'total' => 0,
            'sold' => 0,
            'failed' => 0,
            'selling' => 0,
        ];
    }
    
    $bySession[$sessionId]['total']++;
    
    switch ((int)$consign['status']) {
        case 1: $bySession[$sessionId]['selling']++; break;
        case 2: $bySession[$sessionId]['sold']++; break;
        case 3: $bySession[$sessionId]['failed']++; break;
    }
}

// 获取场次信息
$sessionIds = array_filter(array_keys($bySession), function($id) { return $id > 0; });
if (!empty($sessionIds)) {
    $sessions = Db::name('collection_session')
        ->whereIn('id', $sessionIds)
        ->select()
        ->toArray();
    
    $sessionMap = [];
    foreach ($sessions as $session) {
        $sessionMap[$session['id']] = $session;
    }
    
    echo sprintf("%-5s %-30s %8s %8s %8s %8s %10s\n", 
        "ID", "场次名称", "总数", "已售", "流拍", "寄售中", "成功率"
    );
    echo str_repeat("-", 90) . "\n";
    
    foreach ($bySession as $sessionId => $stats) {
        if ($sessionId === 0) continue;
        
        $session = $sessionMap[$sessionId] ?? null;
        $sessionName = $session ? mb_substr($session['title'], 0, 28) : "未知场次";
        
        $completed = $stats['sold'] + $stats['failed'];
        $rate = $completed > 0 ? round($stats['sold'] / $completed * 100, 1) : 0;
        
        echo sprintf("%-5d %-30s %8d %8d %8d %8d %9.1f%%\n",
            $sessionId,
            $sessionName,
            $stats['total'],
            $stats['sold'],
            $stats['failed'],
            $stats['selling'],
            $rate
        );
    }
}

// ========================================
// 4. 用户寄售排行（TOP 20）
// ========================================
echo "\n📊 【用户寄售排行 TOP 20】\n";
echo "-------------------------------------------\n";

// 按寄售总数排序
uasort($byUser, function($a, $b) {
    return $b['total'] - $a['total'];
});

$topUsers = array_slice($byUser, 0, 20, true);

echo sprintf("%-10s %8s %8s %8s %8s %10s %15s\n", 
    "用户ID", "总寄售", "已售", "流拍", "寄售中", "成功率", "成交金额"
);
echo str_repeat("-", 90) . "\n";

foreach ($topUsers as $userId => $stats) {
    $completed = $stats['sold'] + $stats['failed'];
    $rate = $completed > 0 ? round($stats['sold'] / $completed * 100, 1) : 0;
    
    echo sprintf("%-10d %8d %8d %8d %8d %9.1f%% %15s",
        $userId,
        $stats['total'],
        $stats['sold'],
        $stats['failed'],
        $stats['selling'],
        $rate,
        number_format($stats['sold_value'], 2)
    );
    
    if ($stats['sold'] > 10) {
        echo " 🔥 活跃\n";
    } elseif ($stats['total'] > 5 && $rate < 30) {
        echo " ⚠️ 低成功率\n";
    } else {
        echo "\n";
    }
}

// ========================================
// 5. 成功率分布
// ========================================
echo "\n📊 【用户成功率分布】\n";
echo "-------------------------------------------\n";

$rateDistribution = [
    '0%' => 0,
    '1-30%' => 0,
    '31-50%' => 0,
    '51-70%' => 0,
    '71-90%' => 0,
    '91-99%' => 0,
    '100%' => 0,
];

foreach ($byUser as $stats) {
    $completed = $stats['sold'] + $stats['failed'];
    if ($completed === 0) continue; // 排除仅有寄售中的用户
    
    $rate = round($stats['sold'] / $completed * 100, 1);
    
    if ($rate === 0) $rateDistribution['0%']++;
    elseif ($rate < 31) $rateDistribution['1-30%']++;
    elseif ($rate < 51) $rateDistribution['31-50%']++;
    elseif ($rate < 71) $rateDistribution['51-70%']++;
    elseif ($rate < 91) $rateDistribution['71-90%']++;
    elseif ($rate < 100) $rateDistribution['91-99%']++;
    else $rateDistribution['100%']++;
}

$totalUsersWithHistory = array_sum($rateDistribution);

foreach ($rateDistribution as $range => $count) {
    $pct = $totalUsersWithHistory > 0 ? round($count / $totalUsersWithHistory * 100, 1) : 0;
    
    $bar = str_repeat('█', min(50, (int)($pct * 0.5)));
    echo sprintf("%-15s: %5d 用户 (%5.1f%%) %s\n", 
        $range, 
        $count, 
        $pct,
        $bar
    );
}

echo "\n总参与用户: " . count($byUser) . " 人\n";
echo "有完成记录: {$totalUsersWithHistory} 人\n";

// ========================================
// 6. 综合评估
// ========================================
echo "\n📊 【综合评估】\n";
echo "===========================================\n";

echo "寄售市场活跃度: ";
if ($totalCount > 500) {
    echo "🔥 非常活跃 ({$totalCount}条记录)\n";
} elseif ($totalCount > 200) {
    echo "✅ 活跃 ({$totalCount}条记录)\n";
} else {
    echo "⚠️ 一般 ({$totalCount}条记录)\n";
}

echo "\n成交效率评价: ";
if ($successRate >= 80) {
    echo "🌟 优秀 ({$successRate}%)\n";
} elseif ($successRate >= 60) {
    echo "✅ 良好 ({$successRate}%)\n";
} elseif ($successRate >= 40) {
    echo "⚠️ 一般 ({$successRate}%)\n";
} else {
    echo "❌ 较差 ({$successRate}%)\n";
}

if (!empty($soldTimes)) {
    echo "\n成交速度: ";
    if ($avgTime < 24) {
        echo "⚡ 极快 (平均" . round($avgTime) . "小时)\n";
    } elseif ($avgTime < 72) {
        echo "✅ 较快 (平均" . round($avgTime / 24, 1) . "天)\n";
    } else {
        echo "⚠️ 较慢 (平均" . round($avgTime / 24, 1) . "天)\n";
    }
}

echo "\n市场健康度指标:\n";
echo "  - 流拍率: {$failRate}% " . ($failRate < 20 ? "✅ 健康" : "⚠️ 偏高") . "\n";
echo "  - 当前寄售中: {$sellingCount} 单 " . ($sellingCount < $soldCount ? "✅ 合理" : "⚠️ 积压") . "\n";
echo "  - 参与用户数: " . count($byUser) . " 人\n";
echo "  - 人均寄售: " . round($totalCount / count($byUser), 2) . " 单\n";

echo "\n===========================================\n";
echo "分析完成\n";
echo "===========================================\n\n";
