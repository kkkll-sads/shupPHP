<?php
/**
 * 诊断寄售卷 1833 与 资产 37-DATA-0040-0009 的匹配问题
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$couponId = 1833;
$assetCode = '37-DATA-0040-0009';

echo "正在诊断 Coupon {$couponId} vs Asset {$assetCode} ...\n";

// 1. 获取 Coupon 信息
$coupon = Db::name('user_consignment_coupon')->find($couponId);
if (!$coupon) {
    echo "[ERROR] 寄售卷 ID {$couponId} 不存在!\n";
} else {
    echo "\n--- Coupon Info ---\n";
    echo "ID: {$coupon['id']}\n";
    echo "User ID: {$coupon['user_id']}\n";
    echo "Zone ID: {$coupon['zone_id']}\n";
    echo "Session ID: {$coupon['session_id']}\n";
    echo "Price Zone: {$coupon['price_zone']}\n";
    echo "Status: {$coupon['status']} (1=Unused)\n";
    echo "Expire: " . date('Y-m-d H:i:s', $coupon['expire_time']) . "\n";
}

// 2. 获取 Item 信息 (通过 asset_code)
$item = Db::name('collection_item')->where('asset_code', $assetCode)->find();
if (!$item) {
    echo "\n[ERROR] 未找到 asset_code 为 '{$assetCode}' 的物品!\n";
    // 尝试模糊搜索 title
    $similar = Db::name('collection_item')->where('title', 'like', "%{$assetCode}%")->find();
    if ($similar) {
        echo "提示: 也许是 Title? ID: {$similar['id']}, Title: {$similar['title']}\n";
        $item = $similar;
    }
}

if ($item) {
    echo "\n--- Item Info ---\n";
    echo "ID: {$item['id']}\n";
    echo "Title: {$item['title']}\n";
    echo "Asset Code: {$item['asset_code']}\n";
    echo "Price: {$item['price']}\n";
    echo "Zone ID: {$item['zone_id']}\n";
    echo "Price Zone: {$item['price_zone']}\n";
    echo "Session ID: {$item['session_id']}\n";
    
    // Check Match
    if ($coupon) {
        echo "\n--- Matching Analysis ---\n";
        
        // Zone Match
        $zoneMatch = ($coupon['zone_id'] == 0 || $coupon['zone_id'] == $item['zone_id']);
        echo "Zone Match: " . ($zoneMatch ? "YES" : "NO (Coupon: {$coupon['zone_id']} vs Item: {$item['zone_id']})") . "\n";
        
        // Session Match
        $bwSession = ($coupon['session_id'] == 0 || $coupon['session_id'] == $item['session_id']);
        echo "Session Match: " . ($bwSession ? "YES" : "NO (Coupon: {$coupon['session_id']} vs Item: {$item['session_id']})") . "\n";
        
        // Price Zone Match (String comparison?)
    }
}

// Check other coupons for user 520
echo "\n--- User 520 Other Coupons ---\n";
$coupons = Db::name('user_consignment_coupon')
    ->where('user_id', 520)
    ->where('status', 1)
    ->select();

foreach ($coupons as $c) {
    echo "ID: {$c['id']}, Zone: {$c['zone_id']}, PriceZone: {$c['price_zone']}, Session: {$c['session_id']}, Expire: " . date('Y-m-d', $c['expire_time']) . "\n";
}
