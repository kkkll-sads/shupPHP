<?php
/**
 * 查询早场(9:00-12:00)的增值记录
 */

require dirname(__DIR__) . '/vendor/autoload.php';

$app = new think\App(dirname(__DIR__));
$app->initialize();

$today = date('Y-m-d');
$timeStart = strtotime($today . ' 09:00:00');
$timeEnd = strtotime($today . ' 12:00:00');

echo "\n=== 早场增值记录查询 ===\n";
echo "查询时间段: " . date('H:i:s', $timeStart) . ' - ' . date('H:i:s', $timeEnd) . "\n\n";

$logs = \think\facade\Db::name('collection_appreciation_log')
    ->where('create_time', '>=', $timeStart)
    ->where('create_time', '<=', $timeEnd)
    ->order('create_time asc')
    ->select()
    ->toArray();

echo "早场(9:00-12:00)增值记录: " . count($logs) . " 条\n\n";

if (!empty($logs)) {
    echo "增值明细:\n";
    echo sprintf("%-10s %-10s %-12s %-12s %-10s\n", "时间", "藏品ID", "增值前", "增值后", "增幅");
    echo str_repeat('-', 60) . "\n";
    
    foreach ($logs as $log) {
        $rate = (($log['after_price'] - $log['before_price']) / $log['before_price']) * 100;
        echo sprintf("%-10s %-10d %-12.2f %-12.2f +%.1f%%\n",
            date('H:i:s', $log['create_time']),
            $log['item_id'],
            $log['before_price'],
            $log['after_price'],
            $rate
        );
    }
    
    // 统计涉及的藏品
    $itemIds = array_unique(array_column($logs, 'item_id'));
    echo "\n涉及藏品数: " . count($itemIds) . "\n";
    echo "藏品ID列表: " . implode(', ', $itemIds) . "\n";
    
} else {
    echo "✅ 早场没有增值记录\n";
    echo "\n结论：撮合失败时价格没有增值，可以安全重新撮合\n";
}

echo "\n";
