<?php
require dirname(__DIR__) . '/vendor/autoload.php';
use think\facade\Db;
$app = new think\App(dirname(__DIR__));
$app->initialize();

$columns = Db::query("DESC ba_user");
echo "Columns: " . implode(", ", array_column($columns, 'Field')) . "\n";
