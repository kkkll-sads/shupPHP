<?php
/**
 * 扫描 Zone ID 缺失的藏品
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "正在扫描 Zone ID = 0 且 Price > 0 的藏品...\n";

$items = Db::name('collection_item')
    ->where('zone_id', 0)
    ->where('price', '>', 0)
    ->select();

$count = count($items);
echo "发现 {$count} 个潜在问题的藏品:\n";

foreach ($items as $item) {
    echo "ID: {$item['id']}, Title: {$item['title']}, Price: {$item['price']}, PriceZone: '{$item['price_zone']}'\n";
}

// 统计同名分组
$grouped = [];
foreach ($items as $item) {
    $title = $item['title'];
    if (!isset($grouped[$title])) {
        $grouped[$title] = 0;
    }
    $grouped[$title]++;
}

echo "\n--- 按标题分组 ---\n";
foreach ($grouped as $title => $num) {
    echo "{$title}: {$num} 个\n";
}
