<?php
/**
 * 检查当前撮合池状态
 * 统计申购数量、寄售数量以及供需差异
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

// 初始化应用
$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n";
echo "===========================================\n";
echo "      撮合池供需状态检查\n";
echo "===========================================\n";
echo "检查时间: " . date('Y-m-d H:i:s') . "\n";
echo "-------------------------------------------\n\n";

// ========================================
// 1. 统计申购情况（买单）
// ========================================
echo "📊 【申购统计】（买方需求）\n";
echo "-------------------------------------------\n";

// 查询待撮合的买单
$buyOrders = Db::name('collection_matching_pool')
    ->where('status', 'pending')
    ->select()
    ->toArray();

$buyStats = [
    'total_count' => count($buyOrders),
    'total_amount' => 0,
    'by_session' => [],
    'by_item' => [],
];

foreach ($buyOrders as $order) {
    $sessionId = (int)$order['session_id'];
    $itemId = (int)$order['item_id'];
    $price = (float)$order['price'];
    
    $buyStats['total_amount'] += $price;
    
    // 按场次统计
    if (!isset($buyStats['by_session'][$sessionId])) {
        $buyStats['by_session'][$sessionId] = ['count' => 0, 'amount' => 0];
    }
    $buyStats['by_session'][$sessionId]['count']++;
    $buyStats['by_session'][$sessionId]['amount'] += $price;
    
    // 按藏品统计
    if (!isset($buyStats['by_item'][$itemId])) {
        $buyStats['by_item'][$itemId] = ['count' => 0, 'amount' => 0];
    }
    $buyStats['by_item'][$itemId]['count']++;
    $buyStats['by_item'][$itemId]['amount'] += $price;
}

echo "申购总单数: {$buyStats['total_count']} 单\n";
echo "申购总金额: " . number_format($buyStats['total_amount'], 2) . " 元\n";
echo "涉及场次数: " . count($buyStats['by_session']) . " 个\n";
echo "涉及藏品数: " . count($buyStats['by_item']) . " 个\n";

// ========================================
// 2. 统计寄售情况（卖单）
// ========================================
echo "\n📊 【寄售统计】（卖方供给）\n";
echo "-------------------------------------------\n";

// 查询寄售中的藏品
$consignments = Db::name('collection_consignment')
    ->where('status', 1) // 寄售中
    ->select()
    ->toArray();

$sellStats = [
    'total_count' => count($consignments),
    'total_value' => 0,
    'by_session' => [],
    'by_item' => [],
];

foreach ($consignments as $consign) {
    $sessionId = (int)($consign['session_id'] ?? 0);
    $itemId = (int)$consign['item_id'];
    $price = (float)$consign['price'];
    
    $sellStats['total_value'] += $price;
    
    // 按场次统计
    if ($sessionId > 0) {
        if (!isset($sellStats['by_session'][$sessionId])) {
            $sellStats['by_session'][$sessionId] = ['count' => 0, 'value' => 0];
        }
        $sellStats['by_session'][$sessionId]['count']++;
        $sellStats['by_session'][$sessionId]['value'] += $price;
    }
    
    // 按藏品统计
    if (!isset($sellStats['by_item'][$itemId])) {
        $sellStats['by_item'][$itemId] = ['count' => 0, 'value' => 0];
    }
    $sellStats['by_item'][$itemId]['count']++;
    $sellStats['by_item'][$itemId]['value'] += $price;
}

echo "寄售总数量: {$sellStats['total_count']} 个\n";
echo "寄售总价值: " . number_format($sellStats['total_value'], 2) . " 元\n";
echo "涉及场次数: " . count($sellStats['by_session']) . " 个\n";
echo "涉及藏品数: " . count($sellStats['by_item']) . " 个\n";

// ========================================
// 3. 供需对比分析
// ========================================
echo "\n📊 【供需对比】\n";
echo "===========================================\n";

$qtyDiff = $buyStats['total_count'] - $sellStats['total_count'];
$valueDiff = $buyStats['total_amount'] - $sellStats['total_value'];

echo "数量对比:\n";
echo "  - 申购需求: {$buyStats['total_count']} 单\n";
echo "  - 寄售供给: {$sellStats['total_count']} 个\n";
echo "  - 差额: " . ($qtyDiff >= 0 ? '+' : '') . $qtyDiff . " ";
if ($qtyDiff > 0) {
    echo "（需求大于供给，供不应求）\n";
} elseif ($qtyDiff < 0) {
    echo "（供给大于需求，供过于求）\n";
} else {
    echo "（供需平衡）\n";
}

echo "\n金额对比:\n";
echo "  - 申购金额: " . number_format($buyStats['total_amount'], 2) . " 元\n";
echo "  - 寄售价值: " . number_format($sellStats['total_value'], 2) . " 元\n";
echo "  - 差额: " . ($valueDiff >= 0 ? '+' : '') . number_format($valueDiff, 2) . " 元\n";

// ========================================
// 4. 按场次详细对比
// ========================================
echo "\n📊 【按场次详细对比】\n";
echo "-------------------------------------------\n";

// 获取所有涉及的场次
$allSessionIds = array_unique(array_merge(
    array_keys($buyStats['by_session']),
    array_keys($sellStats['by_session'])
));

if (empty($allSessionIds)) {
    echo "暂无活跃场次\n";
} else {
    // 获取场次信息
    $sessions = Db::name('collection_session')
        ->whereIn('id', $allSessionIds)
        ->select()
        ->toArray();
    
    $sessionMap = [];
    foreach ($sessions as $session) {
        $sessionMap[$session['id']] = $session;
    }
    
    foreach ($allSessionIds as $sessionId) {
        $session = $sessionMap[$sessionId] ?? null;
        $sessionName = $session ? $session['title'] : "场次#{$sessionId}";
        
        $buyCount = $buyStats['by_session'][$sessionId]['count'] ?? 0;
        $sellCount = $sellStats['by_session'][$sessionId]['count'] ?? 0;
        $diff = $buyCount - $sellCount;
        
        echo "\n场次: {$sessionName} (ID: {$sessionId})\n";
        echo "  申购: {$buyCount} 单\n";
        echo "  寄售: {$sellCount} 个\n";
        echo "  差额: " . ($diff >= 0 ? '+' : '') . $diff;
        
        if ($diff > 0) {
            echo " ⚠️ 供不应求\n";
        } elseif ($diff < 0) {
            echo " ✓ 供给充足\n";
        } else {
            echo " ✓ 供需平衡\n";
        }
    }
}

// ========================================
// 5. 官方库存对比
// ========================================
echo "\n📊 【官方库存统计】\n";
echo "-------------------------------------------\n";

// 获取所有涉及的藏品
$allItemIds = array_unique(array_merge(
    array_keys($buyStats['by_item']),
    array_keys($sellStats['by_item'])
));

if (!empty($allItemIds)) {
    $items = Db::name('collection_item')
        ->whereIn('id', $allItemIds)
        ->select()
        ->toArray();
    
    $totalOfficialStock = 0;
    $totalAvailable = 0;
    
    echo sprintf("%-40s %8s %8s %10s %10s\n", "藏品名称", "申购", "寄售", "官方库存", "总库存");
    echo str_repeat("-", 80) . "\n";
    
    foreach ($items as $item) {
        $itemId = $item['id'];
        $title = mb_substr($item['title'], 0, 18);
        $officialStock = (int)$item['stock'];
        $buyCount = $buyStats['by_item'][$itemId]['count'] ?? 0;
        $sellCount = $sellStats['by_item'][$itemId]['count'] ?? 0;
        $available = $officialStock + $sellCount;
        
        $totalOfficialStock += $officialStock;
        $totalAvailable += $available;
        
        echo sprintf("%-40s %8d %8d %10d %10d", 
            $title, 
            $buyCount, 
            $sellCount, 
            $officialStock,
            $available
        );
        
        if ($buyCount > $available) {
            echo " ⚠️ 库存不足\n";
        } else {
            echo " ✓\n";
        }
    }
    
    echo str_repeat("-", 80) . "\n";
    echo "官方总库存: {$totalOfficialStock}\n";
    echo "总可售库存: {$totalAvailable} (官方 + 寄售)\n";
    echo "申购总需求: {$buyStats['total_count']}\n";
    
    $coverageRate = $totalAvailable > 0 
        ? round($buyStats['total_count'] / $totalAvailable * 100, 2) 
        : 0;
    echo "需求覆盖率: {$coverageRate}%\n";
}

echo "\n===========================================\n";
echo "检查完成\n";
echo "===========================================\n\n";
