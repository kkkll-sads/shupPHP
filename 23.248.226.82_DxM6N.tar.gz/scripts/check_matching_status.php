<?php
/**
 * 检查撮合失败的数据状态
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n";
echo "===========================================\n";
echo "   撮合失败数据状态检查\n";
echo "===========================================\n";
echo "检查时间: " . date('Y-m-d H:i:s') . "\n";
echo "-------------------------------------------\n\n";

// 1. 预约池状态
echo "📊 【预约池状态】\n";
echo "-------------------------------------------\n";

$reservationStats = Db::name('trade_reservations')
    ->field('status, COUNT(*) as count')
    ->group('status')
    ->select()
    ->toArray();

$statusMap = [
    0 => '待撮合',
    1 => '已中签',
    2 => '未中签',
    3 => '已取消',
];

foreach ($reservationStats as $stat) {
    $statusText = $statusMap[$stat['status']] ?? "未知({$stat['status']})";
    echo "{$statusText}: {$stat['count']} 单\n";
}

// 2. 检查今天12:00-12:20的增值记录
echo "\n📊 【增值记录】(12:00-12:20)\n";
echo "-------------------------------------------\n";

$today = date('Y-m-d');
$timeStart = strtotime($today . ' 12:00:00');
$timeEnd = strtotime($today . ' 12:20:00');

$appreciationLogs = Db::name('collection_appreciation_log')
    ->where('create_time', '>=', $timeStart)
    ->where('create_time', '<=', $timeEnd)
    ->order('create_time asc')
    ->select()
    ->toArray();

echo "增值记录数: " . count($appreciationLogs) . "\n\n";

if (!empty($appreciationLogs)) {
    echo sprintf("%-10s %-15s %-15s %-10s %-20s\n", "藏品ID", "增值前", "增值后", "增值率", "时间");
    echo str_repeat("-", 80) . "\n";
    
    foreach ($appreciationLogs as $log) {
        echo sprintf("%-10d %-15s %-15s %-10s %-20s\n",
            $log['item_id'],
            number_format($log['before_price'], 2),
            number_format($log['after_price'], 2),
            ($log['rate'] * 100) . '%',
            date('H:i:s', $log['create_time'])
        );
    }
    
    // 3. 检查这些藏品的当前价格
    echo "\n📊 【藏品当前价格】\n";
    echo "-------------------------------------------\n";
    
    $itemIds = array_unique(array_column($appreciationLogs, 'item_id'));
    $items = Db::name('collection_item')
        ->whereIn('id', $itemIds)
        ->select()
        ->toArray();
    
    echo sprintf("%-10s %-40s %-15s %-20s\n", "藏品ID", "名称", "当前价格", "更新时间");
    echo str_repeat("-", 90) . "\n";
    
    foreach ($items as $item) {
        echo sprintf("%-10d %-40s %-15s %-20s\n",
            $item['id'],
            mb_substr($item['title'], 0, 38),
            $item['price'],
            date('H:i:s', $item['update_time'])
        );
    }
}

// 4. 检查用户531的数据
echo "\n📊 【用户531状态】\n";
echo "-------------------------------------------\n";

$user531Reservations = Db::name('trade_reservations')
    ->where('user_id', 531)
    ->select()
    ->toArray();

echo "预约记录数: " . count($user531Reservations) . "\n";

if (!empty($user531Reservations)) {
    echo sprintf("%-10s %-10s %-10s %-15s %-20s\n", "预约ID", "状态", "藏品ID", "冻结金额", "创建时间");
    echo str_repeat("-", 80) . "\n";
    
    foreach ($user531Reservations as $res) {
        $statusText = $statusMap[$res['status']] ?? "未知";
        echo sprintf("%-10d %-10s %-10d %-15s %-20s\n",
            $res['id'],
            $statusText,
            $res['item_id'],
            $res['freeze_amount'],
            date('H:i:s', $res['create_time'])
        );
    }
}

// 5. 检查撮合池状态
echo "\n📊 【撮合池状态】\n";
echo "-------------------------------------------\n";

$matchingPool = Db::name('collection_matching_pool')
    ->where('status', 'pending')
    ->count();

echo "待撮合买单: {$matchingPool} 单\n";

echo "\n===========================================\n";
echo "检查完成\n";
echo "===========================================\n\n";
