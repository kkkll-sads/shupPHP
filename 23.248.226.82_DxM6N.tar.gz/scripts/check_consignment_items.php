<?php
/**
 * 详细检查寄售藏品和资产包情况
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

// 初始化应用
$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n";
echo "===========================================\n";
echo "   寄售藏品详细分析（按资产包）\n";
echo "===========================================\n";
echo "检查时间: " . date('Y-m-d H:i:s') . "\n";
echo "-------------------------------------------\n\n";

// ========================================
// 1. 查询所有寄售中的记录
// ========================================
echo "📊 【寄售中的藏品】\n";
echo "-------------------------------------------\n";

$consignments = Db::name('collection_consignment')
    ->alias('cc')
    ->leftJoin('user_collection uc', 'cc.user_collection_id = uc.id')
    ->leftJoin('collection_item ci', 'cc.item_id = ci.id')
    ->where('cc.status', 1) // 寄售中
    ->field('cc.*, uc.is_old_asset_package, ci.title as item_title, ci.package_id')
    ->select()
    ->toArray();

echo "寄售中总数: " . count($consignments) . " 个\n\n";

// 按资产包分组
$byPackage = [];
$byItem = [];
$isOldAsset = 0;
$isNormalAsset = 0;

foreach ($consignments as $consign) {
    $packageId = (int)($consign['package_id'] ?? 0);
    $itemId = (int)$consign['item_id'];
    $itemTitle = $consign['item_title'] ?? '未知藏品';
    $isOld = (int)($consign['is_old_asset_package'] ?? 0);
    $price = (float)$consign['price'];
    
    // 统计旧资产和普通资产
    if ($isOld === 1) {
        $isOldAsset++;
    } else {
        $isNormalAsset++;
    }
    
    // 按资产包统计
    if (!isset($byPackage[$packageId])) {
        $byPackage[$packageId] = [
            'count' => 0,
            'value' => 0,
            'items' => [],
        ];
    }
    $byPackage[$packageId]['count']++;
    $byPackage[$packageId]['value'] += $price;
    
    // 按藏品统计
    if (!isset($byItem[$itemId])) {
        $byItem[$itemId] = [
            'title' => $itemTitle,
            'package_id' => $packageId,
            'count' => 0,
            'value' => 0,
            'old_asset_count' => 0,
            'normal_asset_count' => 0,
        ];
    }
    $byItem[$itemId]['count']++;
    $byItem[$itemId]['value'] += $price;
    
    if ($isOld === 1) {
        $byItem[$itemId]['old_asset_count']++;
    } else {
        $byItem[$itemId]['normal_asset_count']++;
    }
}

echo "旧资产寄售: {$isOldAsset} 个\n";
echo "普通资产寄售: {$isNormalAsset} 个\n";

// ========================================
// 2. 获取资产包信息
// ========================================
echo "\n📊 【按资产包分类】\n";
echo "-------------------------------------------\n";

if (!empty($byPackage)) {
    $packageIds = array_keys($byPackage);
    $packages = Db::name('asset_package')
        ->whereIn('id', $packageIds)
        ->select()
        ->toArray();
    
    $packageMap = [];
    foreach ($packages as $package) {
        $packageMap[$package['id']] = $package;
    }
    
    echo sprintf("%-5s %-30s %10s %15s\n", "ID", "资产包名称", "数量", "总价值");
    echo str_repeat("-", 70) . "\n";
    
    foreach ($byPackage as $packageId => $stats) {
        $package = $packageMap[$packageId] ?? null;
        $packageName = $package ? $package['name'] : "未知资产包#{$packageId}";
        
        echo sprintf("%-5d %-30s %10d %15s\n",
            $packageId,
            mb_substr($packageName, 0, 28),
            $stats['count'],
            number_format($stats['value'], 2)
        );
    }
}

// ========================================
// 3. 按藏品详细列表
// ========================================
echo "\n📊 【按藏品详细列表】\n";
echo "-------------------------------------------\n";

echo sprintf("%-5s %-40s %8s %8s %8s %12s\n", 
    "ID", "藏品名称", "总数", "旧资产", "普通", "总价值"
);
echo str_repeat("-", 95) . "\n";

// 按数量排序
uasort($byItem, function($a, $b) {
    return $b['count'] - $a['count'];
});

foreach ($byItem as $itemId => $stats) {
    echo sprintf("%-5d %-40s %8d %8d %8d %12s\n",
        $itemId,
        mb_substr($stats['title'], 0, 38),
        $stats['count'],
        $stats['old_asset_count'],
        $stats['normal_asset_count'],
        number_format($stats['value'], 2)
    );
}

// ========================================
// 4. 具体寄售记录示例（前30条）
// ========================================
echo "\n📊 【寄售记录详细列表】（前30条）\n";
echo "-------------------------------------------\n";

echo sprintf("%-5s %-10s %-30s %10s %8s %12s\n", 
    "ID", "用户ID", "藏品名称", "价格", "类型", "挂单时间"
);
echo str_repeat("-", 95) . "\n";

$displayed = 0;
foreach ($consignments as $consign) {
    if ($displayed >= 30) break;
    
    $itemTitle = $consign['item_title'] ?? '未知';
    $price = (float)$consign['price'];
    $userId = (int)$consign['user_id'];
    $isOld = (int)($consign['is_old_asset_package'] ?? 0);
    $createTime = (int)$consign['create_time'];
    
    echo sprintf("%-5d %-10d %-30s %10s %8s %12s\n",
        $consign['id'],
        $userId,
        mb_substr($itemTitle, 0, 28),
        number_format($price, 2),
        $isOld === 1 ? '旧资产' : '普通',
        date('m-d H:i', $createTime)
    );
    
    $displayed++;
}

if (count($consignments) > 30) {
    echo "... 还有 " . (count($consignments) - 30) . " 条记录未显示\n";
}

// ========================================
// 5. 检查是否都是两个主要藏品
// ========================================
echo "\n📊 【主要藏品分析】\n";
echo "-------------------------------------------\n";

$mainItems = [];
foreach ($byItem as $itemId => $stats) {
    $mainItems[] = [
        'id' => $itemId,
        'title' => $stats['title'],
        'count' => $stats['count'],
        'old_count' => $stats['old_asset_count'],
        'normal_count' => $stats['normal_asset_count'],
    ];
}

// 按数量排序
usort($mainItems, function($a, $b) {
    return $b['count'] - $a['count'];
});

$top2 = array_slice($mainItems, 0, 2);

echo "TOP 2 寄售藏品:\n";
foreach ($top2 as $idx => $item) {
    echo "\n" . ($idx + 1) . ". {$item['title']}\n";
    echo "   - 总数: {$item['count']} 个\n";
    echo "   - 旧资产: {$item['old_count']} 个\n";
    echo "   - 普通: {$item['normal_count']} 个\n";
}

$top2Count = array_sum(array_column($top2, 'count'));
$totalCount = count($consignments);

echo "\nTOP 2 占比: {$top2Count} / {$totalCount} = " . round($top2Count / $totalCount * 100, 1) . "%\n";

if ($top2Count >= $totalCount * 0.9) {
    echo "✅ 确认：主要就是这两个藏品\n";
} else {
    echo "⚠️ 还有其他藏品在寄售\n";
}

// ========================================
// 6. 检查所有寄售记录（包括非寄售中）
// ========================================
echo "\n📊 【所有状态寄售记录统计】\n";
echo "-------------------------------------------\n";

$allConsignments = Db::name('collection_consignment')
    ->alias('cc')
    ->leftJoin('user_collection uc', 'cc.user_collection_id = uc.id')
    ->field('cc.status, uc.is_old_asset_package, COUNT(*) as count')
    ->group('cc.status, uc.is_old_asset_package')
    ->select()
    ->toArray();

$statusNames = [
    0 => '已取消',
    1 => '寄售中',
    2 => '已售出',
    3 => '已下架',
];

foreach ($allConsignments as $row) {
    $status = (int)$row['status'];
    $isOld = (int)($row['is_old_asset_package'] ?? 0);
    $count = (int)$row['count'];
    $statusName = $statusNames[$status] ?? "未知({$status})";
    $assetType = $isOld === 1 ? '旧资产' : '普通资产';
    
    echo sprintf("%-10s - %-10s: %5d 条\n", $statusName, $assetType, $count);
}

echo "\n===========================================\n";
echo "检查完成\n";
echo "===========================================\n\n";
