<?php
/**
 * 执行资产包合并 (Package ID 52 -> 45)
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$sourcePkgId = 52;
$targetPkgId = 45;

echo "开始合并 Package {$sourcePkgId} 到 {$targetPkgId} ...\n";

// 1. 获取目标包信息 (为了名称)
$targetItem = Db::name('collection_item')->where('package_id', $targetPkgId)->find();

if (!$targetItem) {
    echo "[ERROR] 目标包 (ID {$targetPkgId}) 中没有物品，无法获取正确的包名。\n";
    // 这种情况下，也许只更新ID？或者需要人工指定名称？
    // 假设目标包可能为空？如果为空，合并过去也就是创建新包（复用ID）。
    // 但用户说是“合并到45”，暗示45存在。
    echo "请确认目标包 ID 45 是否正确存在。\n";
    exit;
}

$targetPkgName = $targetItem['package_name'];
echo "目标包名称: {$targetPkgName}\n";

// 2. 执行更新
$count = Db::name('collection_item')->where('package_id', $sourcePkgId)->count();
echo "待更新物品数: {$count}\n";

if ($count > 0) {
    $updated = Db::name('collection_item')
        ->where('package_id', $sourcePkgId)
        ->update([
            'package_id' => $targetPkgId,
            'package_name' => $targetPkgName,
            'update_time' => time()
        ]);
    
    echo "成功更新 {$updated} 条记录。\n";
} else {
    echo "源包为空，无需操作。\n";
}

echo "合并完成。\n";
