<?php
/**
 * 分析资产包合并风险 (Package ID 52 -> 45)
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$sourcePkgId = 52;
$targetPkgId = 45;

echo "正在分析将 Package ID {$sourcePkgId} 合并到 {$targetPkgId} ...\n";

// 1. 统计数量
$sourceItems = Db::name('collection_item')->where('package_id', $sourcePkgId)->select();
$targetItems = Db::name('collection_item')->where('package_id', $targetPkgId)->select();

echo "源包 (ID {$sourcePkgId}) 包含物品数: " . count($sourceItems) . "\n";
echo "目标包 (ID {$targetPkgId}) 包含物品数: " . count($targetItems) . "\n";

if (count($sourceItems) == 0) {
    echo "源包为空，无需合并。\n";
    exit;
}

// 2. 样本对比
$s1 = $sourceItems[0];
$t1 = count($targetItems) > 0 ? $targetItems[0] : null;

echo "\n--- 样本对比 ---\n";
echo "属性\t\t源包 (Sample)\t\t目标包 (Sample)\n";
echo "名称\t\t{$s1['title']}\t\t" . ($t1 ? $t1['title'] : 'N/A') . "\n";
echo "价格\t\t{$s1['price']}\t\t" . ($t1 ? $t1['price'] : 'N/A') . "\n";
echo "ZoneID\t\t{$s1['zone_id']}\t\t" . ($t1 ? $t1['zone_id'] : 'N/A') . "\n";
echo "PriceZone\t{$s1['price_zone']}\t" . ($t1 ? $t1['price_zone'] : 'N/A') . "\n";

// 3. 价格一致性检查
$sPrices = array_unique(array_column($sourceItems->toArray(), 'price'));
$tPrices = $t1 ? array_unique(array_column($targetItems->toArray(), 'price')) : [];

echo "\n--- 价格一致性 ---\n";
echo "源包价格分布: " . implode(', ', $sPrices) . "\n";
echo "目标包价格分布: " . implode(', ', $tPrices) . "\n";

if ($t1 && count(array_diff($sPrices, $tPrices)) > 0) {
    echo "[WARNING] 价格不一致! 合并后资产价格将发生变化（如果仅仅是改包号，价格属性在Item上，可能不变，但如果业务逻辑依赖包号定价则有影响）。\n";
}

// 4. 用户持仓检查
$itemIds = array_column($sourceItems->toArray(), 'id');
$userCount = Db::name('user_collection')->whereIn('item_id', $itemIds)->count();
echo "\n涉及用户持仓记录: {$userCount} 条\n";

// 5. 寄售检查
$consignCount = Db::name('collection_consignment')->whereIn('item_id', $itemIds)->where('status', 1)->count();
echo "涉及正在寄售的记录: {$consignCount} 条\n";

echo "\n--- 建议 ---\n";
echo "如果执行合并，将把 collection_item 表中 package_id={$sourcePkgId} 的记录更新为 package_id={$targetPkgId}。\n";
echo "请确认是否继续。\n";
