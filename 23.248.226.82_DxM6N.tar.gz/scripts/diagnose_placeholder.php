<?php

namespace scripts;

use think\facade\Db;
use app\common\service\core\MarketService;

require __DIR__ . '/../vendor/autoload.php';

// Initialize ThinkPHP
$app = new \think\App();
$http = $app->http;
$response = $http->run();

// Manual DB Logic if needed, but often ThinkPHP scripts need bootstrapping context.
// Better to run this via `php think run_script` if such a thing existed, or put it in `app/command`.
// I'll assume I can run it if I namespace it or use `php think` context?
// Actually, using `php public/index.php` style is hard for scripts.
// The easiest way is to make it a Command.

echo "Use: php think diagnose:cross-zone\n";
