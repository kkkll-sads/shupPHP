<?php
/**
 * 修复藏品 Zone ID 缺失问题
 * 针对 Asset ID 4421 (海洋牧场生物资产)
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$userId = 766; // m13256601234
$assetId = 4421;

echo "正在修复资产 ID: {$assetId} ...\n";

$asset = Db::name('user_collection')
    ->alias('uc')
    ->where('uc.id', $assetId)
    ->find();

if (!$asset) {
    echo "资产不存在!\n";
    exit;
}

$itemId = $asset['item_id'];
echo "关联 Item ID: {$itemId}\n";

$item = Db::name('collection_item')->where('id', $itemId)->find();
echo "当前 Zone ID: {$item['zone_id']}, Price Zone: {$item['price_zone']}\n";

// 修复数据
// 设置 Zone ID = 10 (匹配 coupon 1954)
// 设置 Price Zone = '3000元区' (为了以防万一)
Db::name('collection_item')
    ->where('id', $itemId)
    ->update([
        'zone_id' => 10,
        'price_zone' => '3000元区', // 保持与其他物品一致的格式? 或者 '3000'?
        // 观察 diagnostic output: Asset 3318 has '1200元区'. 
        // Coupon 1954 has '3000'.
        // 匹配逻辑可能容错，或者只看 zone_id.
        // 如果系统严格比对 zone_id, 那么 zone_id 是关键。
    ]);
    
echo "修复完成! 已将 Item ID {$itemId} 的 Zone ID 设置为 10。\n";
