<?php
/**
 * 批量注册用户、实名、添加余额、预约撮合脚本
 * 使用方法: php scripts/batch_register_users.php 4E4325 20
 */

// 引入ThinkPHP框架
require __DIR__ . '/../vendor/autoload.php';

$app = new think\App();
$app->initialize();

use think\facade\Db;

// 辅助函数
if (!function_exists('hash_password')) {
    function hash_password($password) {
        return md5($password . 'think');
    }
}

if (!function_exists('generateSJSFlowNo')) {
    function generateSJSFlowNo($userId) {
        return 'SJS' . date('YmdHis') . str_pad((string)$userId, 6, '0', STR_PAD_LEFT) . rand(100, 999);
    }
}

if (!function_exists('generateBatchNo')) {
    function generateBatchNo($prefix, $id) {
        return $prefix . '_' . date('Ymd') . '_' . str_pad((string)$id, 8, '0', STR_PAD_LEFT);
    }
}

// 获取命令行参数
$inviteCode = $argv[1] ?? '4E4325';
$count = (int)($argv[2] ?? 20);
$balance = (float)($argv[3] ?? 10000);
$sessionId = (int)($argv[4] ?? 5); // 默认场次ID 5（别动）
$zoneId = (int)($argv[5] ?? 1); // 默认价格分区ID 1
$packageId = (int)($argv[6] ?? 20); // 默认资产包ID 20

echo "========================================\n";
echo "批量注册用户脚本\n";
echo "========================================\n";
echo "邀请码: {$inviteCode}\n";
echo "注册数量: {$count}\n";
echo "可用余额: {$balance}\n";
echo "场次ID: {$sessionId}\n";
echo "价格分区ID: {$zoneId}\n";
echo "资产包ID: {$packageId}\n";
echo "========================================\n\n";

// 1. 验证邀请码
$inviteCodeInfo = Db::name('invite_code')->where('code', $inviteCode)->find();
if (!$inviteCodeInfo) {
    // 尝试从用户表查找
    $inviter = Db::name('user')->where('invite_code', $inviteCode)->where('status', 'enable')->find();
    if (!$inviter) {
        echo "❌ 邀请码不存在: {$inviteCode}\n";
        exit(1);
    }
    $inviterId = $inviter['id'];
} else {
    $inviterId = $inviteCodeInfo['user_id'];
}

echo "✓ 邀请码验证通过，邀请人ID: {$inviterId}\n";

// 2. 验证场次和分区
if ($sessionId > 0) {
    $session = Db::name('collection_session')->where('id', $sessionId)->where('status', '1')->find();
    if (!$session) {
        echo "❌ 场次不存在或未启用: {$sessionId}\n";
        exit(1);
    }
    echo "✓ 场次验证通过: {$session['title']}\n";
}

if ($zoneId > 0) {
    $zone = Db::name('price_zone_config')->where('id', $zoneId)->where('status', '1')->find();
    if (!$zone) {
        echo "❌ 价格分区不存在或未启用: {$zoneId}\n";
        exit(1);
    }
    echo "✓ 价格分区验证通过: {$zone['name']} (最高价: {$zone['max_price']})\n";
}

if ($packageId > 0) {
    $package = Db::name('asset_package')->where('id', $packageId)->where('status', 1)->find();
    if (!$package) {
        echo "❌ 资产包不存在或未启用: {$packageId}\n";
        exit(1);
    }
    echo "✓ 资产包验证通过: {$package['name']}\n";
}

echo "\n";

// 3. 批量注册用户
$successCount = 0;
$failedCount = 0;
$userIds = [];

for ($i = 1; $i <= $count; $i++) {
    try {
        Db::startTrans();

        // 生成唯一的手机号（使用时间戳+序号）
        $timestamp = time();
        $mobile = '1' . str_pad((string)(($timestamp % 100000000) + $i), 9, '0', STR_PAD_LEFT);
        $mobile = substr($mobile, 0, 11); // 确保11位

        // 检查手机号是否已存在
        $exists = Db::name('user')->where('mobile', $mobile)->find();
        if ($exists) {
            $mobile = '1' . str_pad((string)(($timestamp + $i) % 1000000000), 10, '0', STR_PAD_LEFT);
            $mobile = substr($mobile, 0, 11);
        }

        $username = 'm' . $mobile;
        $password = '123456';
        $payPassword = '123456';

        // 生成用户邀请码（6位随机字母数字）
        $userInviteCode = strtoupper(substr(md5(uniqid() . $mobile . $i), 0, 6));

        // 检查用户邀请码是否重复
        while (Db::name('user')->where('invite_code', $userInviteCode)->find()) {
            $userInviteCode = strtoupper(substr(md5(uniqid() . time() . $i), 0, 6));
        }

        // 生成身份证号（18位）
        $idCard = '11010119900101' . str_pad((string)$i, 4, '0', STR_PAD_LEFT);

        // 注册用户
        $userId = Db::name('user')->insertGetId([
            'username' => $username,
            'nickname' => '测试用户' . $i,
            'mobile' => $mobile,
            'password' => hash_password($password),
            'pay_password' => $payPassword, // 支付密码不加密
            'invite_code' => $userInviteCode,
            'inviter_id' => $inviterId,
            'status' => 'enable',
            'balance_available' => $balance,
            'money' => $balance, // 总资产
            'real_name' => '测试' . $i,
            'id_card' => $idCard,
            'real_name_status' => 2, // 已通过实名
            'audit_time' => time(),
            'create_time' => time(),
            'update_time' => time(),
        ]);

        // 记录余额变动日志
        Db::name('user_money_log')->insert([
            'user_id' => $userId,
            'money' => $balance,
            'before' => 0,
            'after' => $balance,
            'memo' => '批量注册初始余额',
            'create_time' => time(),
        ]);

        // 记录活动日志
        Db::name('user_activity_log')->insert([
            'user_id' => $userId,
            'related_user_id' => 0,
            'action_type' => 'register',
            'change_field' => 'balance_available',
            'change_value' => (string)$balance,
            'before_value' => '0',
            'after_value' => (string)$balance,
            'remark' => '批量注册用户，初始余额',
            'create_time' => time(),
            'update_time' => time(),
        ]);

        // 如果指定了场次和分区，创建预约
        if ($sessionId > 0 && $zoneId > 0 && $packageId > 0) {
            $zone = Db::name('price_zone_config')->where('id', $zoneId)->find();
            $freezeAmount = (float)($zone['max_price'] ?? 2000); // 使用分区最高价作为冻结金额
            
            // 检查用户余额是否足够
            if ($balance >= $freezeAmount) {
                // 计算算力（简化处理，使用固定值）
                $baseHashrate = 10.0;
                $totalHashrate = $baseHashrate;
                $weight = (int)($totalHashrate * 20);

                // 扣除冻结金额
                $afterBalance = $balance - $freezeAmount;
                Db::name('user')->where('id', $userId)->update([
                    'balance_available' => $afterBalance,
                    'money' => $afterBalance,
                ]);

                // 创建预约记录
                $reservationId = Db::name('trade_reservations')->insertGetId([
                    'user_id' => $userId,
                    'session_id' => $sessionId,
                    'zone_id' => $zoneId,
                    'package_id' => $packageId,
                    'product_id' => 0, // 盲盒模式
                    'freeze_amount' => $freezeAmount,
                    'power_used' => $totalHashrate,
                    'base_hashrate_cost' => $baseHashrate,
                    'extra_hashrate_cost' => 0,
                    'weight' => $weight,
                    'status' => 0, // 待撮合
                    'match_order_id' => 0,
                    'match_time' => 0,
                    'create_time' => time(),
                    'update_time' => time(),
                ]);

                // 记录余额变动日志
                $flowNo = generateSJSFlowNo($userId);
                $batchNo = generateBatchNo('BLIND_BOX_RESERVE', $reservationId);
                Db::name('user_money_log')->insert([
                    'user_id' => $userId,
                    'flow_no' => $flowNo,
                    'batch_no' => $batchNo,
                    'biz_type' => 'blind_box_reserve',
                    'biz_id' => $reservationId,
                    'field_type' => 'balance_available',
                    'money' => -$freezeAmount,
                    'before' => $balance,
                    'after' => $afterBalance,
                    'memo' => '盲盒预约冻结可用余额 - ' . ($zone['name'] ?? ''),
                    'create_time' => time(),
                ]);

                // 记录活动日志
                Db::name('user_activity_log')->insert([
                    'user_id' => $userId,
                    'related_user_id' => 0,
                    'action_type' => 'blind_box_reserve',
                    'change_field' => 'balance_available',
                    'change_value' => (string)(-$freezeAmount),
                    'before_value' => (string)$balance,
                    'after_value' => (string)$afterBalance,
                    'remark' => '盲盒预约冻结 - ' . ($zone['name'] ?? ''),
                    'extra' => json_encode([
                        'session_id' => $sessionId,
                        'zone_id' => $zoneId,
                        'package_id' => $packageId,
                        'reservation_id' => $reservationId,
                    ], JSON_UNESCAPED_UNICODE),
                    'create_time' => time(),
                    'update_time' => time(),
                ]);
            }
        }

        Db::commit();
        $userIds[] = $userId;
        $successCount++;
        echo "✓ [{$i}/{$count}] 用户注册成功: ID={$userId}, 手机号={$mobile}, 用户名={$username}\n";
    } catch (\Exception $e) {
        Db::rollback();
        $failedCount++;
        echo "✗ [{$i}/{$count}] 用户注册失败: " . $e->getMessage() . "\n";
    }
}

echo "\n";
echo "========================================\n";
echo "批量注册完成\n";
echo "成功: {$successCount}\n";
echo "失败: {$failedCount}\n";
echo "用户ID列表: " . implode(', ', $userIds) . "\n";
echo "========================================\n";

<<<<<<< HEAD
=======

>>>>>>> 392e607a6782491114a0aee7408a7d620ecf394f

