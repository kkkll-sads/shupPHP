<?php
/**
 * 给所有用户赠送50算力脚本
 * 使用方法: php scripts/gift_hashrate.php
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n";
echo "========================================\n";
echo "   给所有用户赠送算力脚本\n";
echo "========================================\n";
echo "执行时间: " . date('Y-m-d H:i:s') . "\n\n";

// 配置
$giftAmount = 100.0; // 赠送的算力数量
$now = time();

try {
    // 查询所有用户
    $users = Db::name('user')
        ->where('status', '<>', 'hidden') // 排除隐藏用户
        ->field('id, username, green_power')
        ->select()
        ->toArray();
    
    $totalUsers = count($users);
    echo "查询到用户总数: {$totalUsers}\n";
    
    if ($totalUsers == 0) {
        echo "没有找到用户，脚本退出。\n";
        exit(0);
    }
    
    // 询问确认
    echo "\n即将给 {$totalUsers} 个用户每人赠送 {$giftAmount} 算力!\n";
    echo "是否继续? (输入 yes 确认): ";
    $handle = fopen ("php://stdin","r");
    $line = trim(fgets($handle));
    fclose($handle);
    
    if ($line !== 'yes') {
        echo "操作已取消。\n";
        exit(0);
    }
    
    echo "\n开始执行...\n\n";
    
    $successCount = 0;
    $failCount = 0;
    
    foreach ($users as $user) {
        try {
            Db::startTrans();
            
            $userId = $user['id'];
            $username = $user['username'];
            $beforePower = (float)$user['green_power'];
            $afterPower = round($beforePower + $giftAmount, 2);
            
            // 更新用户算力
            Db::name('user')
                ->where('id', $userId)
                ->update([
                    'green_power' => $afterPower,
                    'update_time' => $now,
                ]);
            
            // 记录资金变动日志
            $flowNo = generateSJSFlowNo($userId);
            Db::name('user_money_log')->insert([
                'user_id' => $userId,
                'flow_no' => $flowNo,
                'batch_no' => 'GIFT_HASHRATE_' . date('Ymd'),
                'biz_type' => 'gift_hashrate',
                'biz_id' => 0,
                'field_type' => 'green_power',
                'money' => $giftAmount,
                'before' => $beforePower,
                'after' => $afterPower,
                'memo' => '系统赠送算力：' . $giftAmount,
                'create_time' => $now,
            ]);
            
            // 记录活动日志
            Db::name('user_activity_log')->insert([
                'user_id' => $userId,
                'related_user_id' => 0,
                'action_type' => 'gift_hashrate',
                'change_field' => 'green_power',
                'change_value' => (string)$giftAmount,
                'before_value' => (string)$beforePower,
                'after_value' => (string)$afterPower,
                'remark' => '系统赠送算力：' . $giftAmount,
                'extra' => json_encode([
                    'gift_amount' => $giftAmount,
                    'batch' => date('Ymd'),
                ], JSON_UNESCAPED_UNICODE),
                'create_time' => $now,
                'update_time' => $now,
            ]);
            
            Db::commit();
            
            $successCount++;
            echo sprintf("✓ [%d/%d] 用户 %s (ID:%d) - 算力: %.2f -> %.2f\n", 
                $successCount + $failCount, 
                $totalUsers, 
                $username, 
                $userId, 
                $beforePower, 
                $afterPower
            );
            
        } catch (\Throwable $e) {
            Db::rollback();
            $failCount++;
            echo sprintf("✗ [%d/%d] 用户 %s (ID:%d) 失败: %s\n", 
                $successCount + $failCount, 
                $totalUsers, 
                $username, 
                $userId, 
                $e->getMessage()
            );
        }
    }
    
    echo "\n========================================\n";
    echo "执行完成!\n";
    echo "========================================\n";
    echo "成功: {$successCount} 个用户\n";
    echo "失败: {$failCount} 个用户\n";
    echo "总计赠送算力: " . number_format($successCount * $giftAmount, 2) . "\n";
    echo "========================================\n\n";
    
} catch (\Throwable $e) {
    echo "\n错误: " . $e->getMessage() . "\n";
    echo "错误文件: " . $e->getFile() . "\n";
    echo "错误行号: " . $e->getLine() . "\n\n";
    exit(1);
}
