<?php
/**
 * 批量修复 Zone ID 缺失的藏品
 * 针对 "海洋牧场生物资产"
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "正在批量修复 '海洋牧场生物资产' (Zone ID = 0)...\n";

$count = Db::name('collection_item')
    ->where('zone_id', 0)
    ->where('title', '海洋牧场生物资产')
    ->count();

echo "发现 {$count} 个未修复项。\n";

if ($count > 0) {
    $updated = Db::name('collection_item')
        ->where('zone_id', 0)
        ->where('title', '海洋牧场生物资产')
        ->update([
            'zone_id' => 10,
            'price_zone' => '3000元区',
            'update_time' => time()
        ]);
    
    echo "成功更新 {$updated} 个藏品。\n";
} else {
    echo "无需更新。\n";
}
