<?php
/**
 * 撮合功能测试脚本
 * 测试盲盒预约撮合功能
 * 
 * 使用方法:
 * php scripts/test_matching.php [session_id]
 */

require __DIR__ . '/../vendor/autoload.php';

$app = new think\App();
$app->initialize();

use think\facade\Db;

echo "========================================\n";
echo "撮合功能测试脚本\n";
echo "========================================\n\n";

// 获取场次ID参数
$sessionId = isset($argv[1]) ? (int)$argv[1] : 0;

// 如果没有指定场次，查找一个启用的场次
if ($sessionId <= 0) {
    $session = Db::name('collection_session')
        ->where('status', '1')
        ->order('id desc')
        ->find();
    
    if ($session) {
        $sessionId = $session['id'];
        echo "使用场次: {$session['title']} (ID: {$sessionId})\n\n";
    } else {
        echo "❌ 没有可用的交易场次\n";
        exit(1);
    }
} else {
    $session = Db::name('collection_session')->where('id', $sessionId)->find();
    if (!$session) {
        echo "❌ 场次不存在: {$sessionId}\n";
        exit(1);
    }
    echo "使用场次: {$session['title']} (ID: {$sessionId})\n\n";
}

// 1. 查看当前预约情况
echo "📋 步骤 1: 查看当前预约情况\n";
echo "----------------------------------------\n";

$reservations = Db::name('trade_reservations')
    ->where('session_id', $sessionId)
    ->where('status', 0) // 待撮合
    ->order('weight desc, create_time asc')
    ->select()
    ->toArray();

echo "待撮合预约数: " . count($reservations) . "\n";

if (!empty($reservations)) {
    echo "\n预约列表（按权重排序）:\n";
    foreach ($reservations as $idx => $res) {
        $user = Db::name('user')->where('id', $res['user_id'])->find();
        echo sprintf(
            "%d. 用户ID=%d (%s) | 分区ID=%d | 权重=%d | 冻结金额=%.2f | 时间=%s\n",
            $idx + 1,
            $res['user_id'],
            $user['username'] ?? 'N/A',
            $res['zone_id'],
            $res['weight'],
            $res['freeze_amount'],
            date('Y-m-d H:i:s', $res['create_time'])
        );
    }
} else {
    echo "⚠️  当前没有待撮合的预约\n";
}

echo "\n";

// 2. 查看可用资产
echo "📋 步骤 2: 查看可用资产\n";
echo "----------------------------------------\n";

// 查询官方库存
$officialItems = Db::name('collection_item')
    ->where('session_id', $sessionId)
    ->where('status', '1')
    ->where('stock', '>', 0)
    ->select()
    ->toArray();

echo "官方库存商品数: " . count($officialItems) . "\n";

// 查询寄售中的商品
$consignments = Db::name('collection_consignment')
    ->alias('cc')
    ->join('collection_item ci', 'cc.item_id = ci.id')
    ->where('ci.session_id', $sessionId)
    ->where('cc.status', 1) // 寄售中
    ->field('cc.*, ci.title, ci.zone_id, ci.price_zone')
    ->order('cc.create_time asc')
    ->select()
    ->toArray();

echo "寄售中商品数: " . count($consignments) . "\n";

if (!empty($consignments)) {
    echo "\n寄售列表（按挂单时间排序）:\n";
    foreach ($consignments as $idx => $cons) {
        echo sprintf(
            "%d. 寄售ID=%d | 商品=%s | 价格=%.2f | 分区=%s | 挂单时间=%s\n",
            $idx + 1,
            $cons['id'],
            $cons['title'] ?? 'N/A',
            $cons['price'],
            $cons['price_zone'] ?? 'N/A',
            date('Y-m-d H:i:s', $cons['create_time'])
        );
    }
}

echo "\n";

// 3. 按分区统计
echo "📋 步骤 3: 按分区统计\n";
echo "----------------------------------------\n";

$zones = Db::name('price_zone_config')
    ->where('status', '1')
    ->order('min_price asc')
    ->select()
    ->toArray();

foreach ($zones as $zone) {
    $zoneReservations = Db::name('trade_reservations')
        ->where('session_id', $sessionId)
        ->where('zone_id', $zone['id'])
        ->where('status', 0)
        ->count();
    
    $zoneConsignments = Db::name('collection_consignment')
        ->alias('cc')
        ->join('collection_item ci', 'cc.item_id = ci.id')
        ->where('ci.session_id', $sessionId)
        ->where('cc.status', 1)
        ->where('ci.zone_id', $zone['id'])
        ->count();
    
    $zoneStock = Db::name('collection_item')
        ->where('session_id', $sessionId)
        ->where('zone_id', $zone['id'])
        ->where('status', '1')
        ->where('stock', '>', 0)
        ->sum('stock');
    
    $totalAvailable = $zoneStock + $zoneConsignments;
    
    echo sprintf(
        "分区: %s (ID:%d) | 预约数:%d | 可用库存:%d (官方:%d + 寄售:%d)\n",
        $zone['name'],
        $zone['id'],
        $zoneReservations,
        $totalAvailable,
        $zoneStock ?? 0,
        $zoneConsignments
    );
}

echo "\n";

// 4. 模拟撮合（不实际执行，只显示匹配结果）
echo "📋 步骤 4: 模拟撮合匹配结果\n";
echo "----------------------------------------\n";

if (empty($reservations)) {
    echo "⚠️  没有待撮合的预约，无法模拟撮合\n\n";
    exit(0);
}

// 按分区分组预约
$reservationsByZone = [];
foreach ($reservations as $res) {
    $zoneId = $res['zone_id'];
    if (!isset($reservationsByZone[$zoneId])) {
        $reservationsByZone[$zoneId] = [];
    }
    $reservationsByZone[$zoneId][] = $res;
}

foreach ($zones as $zone) {
    $zoneId = $zone['id'];
    $zoneReservations = $reservationsByZone[$zoneId] ?? [];
    
    if (empty($zoneReservations)) {
        continue;
    }
    
    // 计算可用库存
    $zoneStock = Db::name('collection_item')
        ->where('session_id', $sessionId)
        ->where('zone_id', $zoneId)
        ->where('status', '1')
        ->where('stock', '>', 0)
        ->sum('stock');
    
    $zoneConsignments = Db::name('collection_consignment')
        ->alias('cc')
        ->join('collection_item ci', 'cc.item_id = ci.id')
        ->where('ci.session_id', $sessionId)
        ->where('cc.status', 1)
        ->where('ci.zone_id', $zoneId)
        ->count();
    
    $totalAvailable = ($zoneStock ?? 0) + $zoneConsignments;
    $reservationCount = count($zoneReservations);
    
    echo "\n分区: {$zone['name']} (ID:{$zoneId})\n";
    echo "  预约数: {$reservationCount}\n";
    echo "  可用库存: {$totalAvailable}\n";
    
    if ($totalAvailable <= 0) {
        echo "  ⚠️  无可用库存，所有预约将退款\n";
        continue;
    }
    
    $matchCount = min($reservationCount, $totalAvailable);
    echo "  预计中签数: {$matchCount}\n";
    echo "  预计未中签数: " . ($reservationCount - $matchCount) . "\n";
    
    // 按权重排序
    usort($zoneReservations, function($a, $b) {
        if ($a['weight'] != $b['weight']) {
            return $b['weight'] - $a['weight']; // 权重降序
        }
        return $a['create_time'] - $b['create_time']; // 时间升序
    });
    
    echo "\n  预计中签列表（前{$matchCount}名）:\n";
    for ($i = 0; $i < $matchCount && $i < count($zoneReservations); $i++) {
        $res = $zoneReservations[$i];
        $user = Db::name('user')->where('id', $res['user_id'])->find();
        echo sprintf(
            "    %d. 用户ID=%d (%s) | 权重=%d\n",
            $i + 1,
            $res['user_id'],
            $user['username'] ?? 'N/A',
            $res['weight']
        );
    }
}

echo "\n";

// 5. 提示执行实际撮合
echo "========================================\n";
echo "提示\n";
echo "========================================\n";
echo "以上为模拟撮合结果，实际撮合需要运行:\n";
echo "php think collection:matching --force\n\n";

<<<<<<< HEAD
=======

>>>>>>> 392e607a6782491114a0aee7408a7d620ecf394f

