<?php
namespace scripts;
use think\facade\Db;
require __DIR__ . '/../vendor/autoload.php';
$app = new \think\App();
$http = $app->http;
$response = $http->run();

$zones = Db::name('price_zone_config')->order('min_price', 'asc')->select();
foreach ($zones as $z) {
    echo "ID: {$z['id']} | Name: {$z['name']} | Range: {$z['min_price']} - {$z['max_price']}\n";
}
