#!/usr/bin/env php
<?php
/**
 * 清理全部测试数据脚本
 * 清理内容：测试用户、寄售记录、订单、藏品、预约等
 */

// 初始化ThinkPHP应用
define('ROOT_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
require ROOT_PATH . 'vendor/autoload.php';

// 加载环境变量
$envFile = ROOT_PATH . '.env';
if (file_exists($envFile)) {
    $env = parse_ini_file($envFile, true);
    foreach ($env as $section => $values) {
        if (is_array($values)) {
            foreach ($values as $key => $value) {
                putenv("{$key}={$value}");
            }
        }
    }
}

// 使用原生PDO连接
$dbHost = getenv('HOSTNAME') ?: '10.10.100.3';
$dbName = getenv('DATABASE') ?: 'waibao';
$dbUser = getenv('USERNAME') ?: 'waibao';
$dbPass = getenv('PASSWORD') ?: 'weHPjtkrbAPSMCNm';
$dbPort = getenv('HOSTPORT') ?: '3306';

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage() . "\n");
}

// 简单的查询封装
function query($pdo, $sql, $params = []) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

function fetchAll($pdo, $sql, $params = []) {
    return query($pdo, $sql, $params)->fetchAll(PDO::FETCH_ASSOC);
}

function fetchColumn($pdo, $sql, $params = []) {
    return query($pdo, $sql, $params)->fetchAll(PDO::FETCH_COLUMN);
}

function execute($pdo, $sql, $params = []) {
    return query($pdo, $sql, $params)->rowCount();
}

echo "========================================\n";
echo "   清理全部测试数据脚本\n";
echo "========================================\n\n";

// 确认操作
echo "⚠️  警告：此操作将清理以下数据：\n";
echo "   - 测试用户（手机号以 138/139 开头）\n";
echo "   - 相关寄售记录\n";
echo "   - 相关订单和订单明细\n";
echo "   - 相关用户藏品\n";
echo "   - 相关预约记录\n";
echo "   - 旧资产解锁生成的藏品商品\n";
echo "   - 相关资金日志\n";
echo "\n";

// 非交互模式直接执行
$confirm = 'y';
if (php_sapi_name() === 'cli' && isset($argv[1]) && $argv[1] === '--yes') {
    $confirm = 'y';
} elseif (php_sapi_name() === 'cli') {
    echo "确认清理？(y/N): ";
    $confirm = trim(fgets(STDIN));
}

if (strtolower($confirm) !== 'y') {
    echo "已取消操作\n";
    exit(0);
}

echo "\n开始清理...\n\n";

$pdo->beginTransaction();
try {
    $stats = [
        'users' => 0,
        'consignments' => 0,
        'orders' => 0,
        'order_items' => 0,
        'user_collections' => 0,
        'reservations' => 0,
        'collection_items' => 0,
        'money_logs' => 0,
        'activity_logs' => 0,
        'unlock_records' => 0,
        'coupons' => 0,
    ];

    // 1. 查找测试用户（手机号以138/139开头，或用户名包含test）
    $testUsers = fetchColumn($pdo, 
        "SELECT id FROM ba_user WHERE mobile LIKE '138%' OR mobile LIKE '139%' OR username LIKE '%test%'"
    );
    
    if (empty($testUsers)) {
        echo "未找到测试用户，检查是否有旧资产解锁生成的商品...\n";
    } else {
        echo "找到 " . count($testUsers) . " 个测试用户\n";
        $userIdList = implode(',', $testUsers);
        
        // 2. 删除测试用户的寄售记录
        $consignmentCount = execute($pdo, 
            "DELETE FROM ba_collection_consignment WHERE user_id IN ({$userIdList})"
        );
        $stats['consignments'] = $consignmentCount;
        echo "  ✓ 删除寄售记录: {$consignmentCount} 条\n";
        
        // 3. 删除测试用户的订单明细
        $orderIds = fetchColumn($pdo, 
            "SELECT id FROM ba_collection_order WHERE user_id IN ({$userIdList})"
        );
        
        if (!empty($orderIds)) {
            $orderIdList = implode(',', $orderIds);
            $orderItemCount = execute($pdo, 
                "DELETE FROM ba_collection_order_item WHERE order_id IN ({$orderIdList})"
            );
            $stats['order_items'] = $orderItemCount;
            echo "  ✓ 删除订单明细: {$orderItemCount} 条\n";
        }
        
        // 4. 删除测试用户的订单
        $orderCount = execute($pdo, 
            "DELETE FROM ba_collection_order WHERE user_id IN ({$userIdList})"
        );
        $stats['orders'] = $orderCount;
        echo "  ✓ 删除订单: {$orderCount} 条\n";
        
        // 5. 删除测试用户的藏品记录
        $userCollectionCount = execute($pdo, 
            "DELETE FROM ba_user_collection WHERE user_id IN ({$userIdList})"
        );
        $stats['user_collections'] = $userCollectionCount;
        echo "  ✓ 删除用户藏品: {$userCollectionCount} 条\n";
        
        // 6. 删除测试用户的预约记录
        $reservationCount = execute($pdo, 
            "DELETE FROM ba_trade_reservations WHERE user_id IN ({$userIdList})"
        );
        $stats['reservations'] = $reservationCount;
        echo "  ✓ 删除预约记录: {$reservationCount} 条\n";
        
        // 7. 删除测试用户的资金日志
        $moneyLogCount = execute($pdo, 
            "DELETE FROM ba_user_money_log WHERE user_id IN ({$userIdList})"
        );
        $stats['money_logs'] = $moneyLogCount;
        echo "  ✓ 删除资金日志: {$moneyLogCount} 条\n";
        
        // 8. 删除测试用户的活动日志
        $activityLogCount = execute($pdo, 
            "DELETE FROM ba_user_activity_log WHERE user_id IN ({$userIdList})"
        );
        $stats['activity_logs'] = $activityLogCount;
        echo "  ✓ 删除活动日志: {$activityLogCount} 条\n";
        
        // 9. 删除测试用户的旧资产解锁记录
        $unlockCount = execute($pdo, 
            "DELETE FROM ba_user_old_assets_unlock WHERE user_id IN ({$userIdList})"
        );
        $stats['unlock_records'] = $unlockCount;
        echo "  ✓ 删除解锁记录: {$unlockCount} 条\n";
        
        // 10. 删除测试用户的寄售券
        $couponCount = execute($pdo, 
            "DELETE FROM ba_user_consignment_coupon WHERE user_id IN ({$userIdList})"
        );
        $stats['coupons'] = $couponCount;
        echo "  ✓ 删除寄售券: {$couponCount} 条\n";
        
        // 11. 删除测试用户
        $userCount = execute($pdo, 
            "DELETE FROM ba_user WHERE id IN ({$userIdList})"
        );
        $stats['users'] = $userCount;
        echo "  ✓ 删除测试用户: {$userCount} 条\n";
    }
    
    // 12. 删除旧资产解锁生成的藏品商品（description = '旧资产解锁生成'）
    $legacyItemCount = execute($pdo, 
        "DELETE FROM ba_collection_item WHERE description = '旧资产解锁生成'"
    );
    $stats['collection_items'] = $legacyItemCount;
    echo "  ✓ 删除旧资产解锁商品: {$legacyItemCount} 条\n";
    
    // 13. 清理孤立的寄售记录（user_id 不存在）
    $orphanConsignments = fetchColumn($pdo, 
        "SELECT c.id FROM ba_collection_consignment c 
         LEFT JOIN ba_user u ON c.user_id = u.id 
         WHERE u.id IS NULL AND c.user_id > 0"
    );
    
    if (!empty($orphanConsignments)) {
        $orphanIdList = implode(',', $orphanConsignments);
        $orphanCount = execute($pdo, 
            "DELETE FROM ba_collection_consignment WHERE id IN ({$orphanIdList})"
        );
        $stats['consignments'] += $orphanCount;
        echo "  ✓ 删除孤立寄售记录: {$orphanCount} 条\n";
    }
    
    $pdo->commit();
    
    echo "\n========================================\n";
    echo "   清理完成！\n";
    echo "========================================\n";
    echo "统计：\n";
    echo "  - 测试用户: {$stats['users']} 条\n";
    echo "  - 寄售记录: {$stats['consignments']} 条\n";
    echo "  - 订单: {$stats['orders']} 条\n";
    echo "  - 订单明细: {$stats['order_items']} 条\n";
    echo "  - 用户藏品: {$stats['user_collections']} 条\n";
    echo "  - 预约记录: {$stats['reservations']} 条\n";
    echo "  - 藏品商品: {$stats['collection_items']} 条\n";
    echo "  - 资金日志: {$stats['money_logs']} 条\n";
    echo "  - 活动日志: {$stats['activity_logs']} 条\n";
    echo "  - 解锁记录: {$stats['unlock_records']} 条\n";
    echo "  - 寄售券: {$stats['coupons']} 条\n";
    echo "\n";
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo "\n❌ 清理失败: " . $e->getMessage() . "\n";
    echo "已回滚所有操作\n";
    exit(1);
}

