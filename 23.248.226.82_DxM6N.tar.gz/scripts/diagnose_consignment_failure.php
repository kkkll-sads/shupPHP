<?php
/**
 * 诊断用户寄售失败问题
 * 用法: php scripts/diagnose_consignment_failure.php <mobile>
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

$app = new think\App(dirname(__DIR__));
$app->initialize();

$mobile = isset($argv[1]) ? $argv[1] : '18510253801';

echo "正在诊断用户: {$mobile}\n";

// 1. 获取用户信息
$user = Db::name('user')->where('mobile', $mobile)->find();
if (!$user) {
    echo "未找到用户!\n";
    exit;
}

$userId = $user['id'];
echo "用户ID: {$userId}, 用户名: {$user['username']}\n";

// 2. 检查最近的寄售卷变动日志
echo "\n--- 最近5条寄售卷(consignment_coupon)变动日志 ---\n";
$couponLogs = Db::name('user_activity_log')
    ->where('user_id', $userId)
    ->where('action_type', 'consignment_coupon_used') // 猜测的 action_type，可能需要根据实际情况调整，先查通用的
    ->order('create_time', 'desc')
    ->limit(5)
    ->select();

// 也没准是在 user_score_log 或者 user_consignment_coupon 关联表?
// 先查 user_activity_log 里的所有最近操作
$recentLogs = Db::name('user_activity_log')
    ->where('user_id', $userId)
    ->order('create_time', 'desc')
    ->limit(10)
    ->select();

foreach ($recentLogs as $log) {
    echo "ID: {$log['id']}, Action: {$log['action_type']}, Remark: {$log['remark']}, Time: " . date('Y-m-d H:i:s', $log['create_time']) . "\n";
}

// 3. 检查用户的藏品资产
echo "\n--- 用户的藏品资产 (ba_user_collection) ---\n";
$assets = Db::name('user_collection')
    ->alias('uc')
    ->join('collection_item ci', 'uc.item_id = ci.id', 'LEFT')
    ->where('uc.user_id', $userId)
    ->field('uc.*, ci.title')
    ->select();

foreach ($assets as $asset) {
    // print_r($asset);
    $status = isset($asset['status']) ? $asset['status'] : 'Unknown';
    echo "Asset ID: {$asset['id']}, Item ID: {$asset['item_id']}, Title: {$asset['title']}, Status: {$status}, CreateTime: " . date('Y-m-d H:i:s', $asset['create_time']) . "\n";
}

// 4. 检查寄售记录
echo "\n--- 最近的寄售记录 (ba_collection_consignment) ---\n";
$consignments = Db::name('collection_consignment')
    ->alias('cc')
    ->join('collection_item ci', 'cc.item_id = ci.id', 'LEFT')
    ->where('cc.user_id', $userId)
    ->field('cc.*, ci.title')
    ->order('cc.create_time', 'desc')
    ->limit(10)
    ->select();

foreach ($consignments as $c) {
    echo "Consign ID: {$c['id']}, Item ID: {$c['item_id']}, Title: {$c['title']}, Status: {$c['status']}, Time: " . date('Y-m-d H:i:s', $c['create_time']) . "\n";
}

// 5. 检查寄售卷表 (ba_user_consignment_coupon)
echo "\n--- 寄售卷表 (ba_user_consignment_coupon) ---\n";

// Show Table Status
$columns = Db::query("DESC ba_user_consignment_coupon");
echo "Columns: " . implode(", ", array_column($columns, 'Field')) . "\n";

// Status Distribution
$statusCounts = Db::name('user_consignment_coupon')->field('status, count(*) as c')->group('status')->select();
echo "Status Distribution: \n";
foreach ($statusCounts as $sc) {
    echo "Status: {$sc['status']} -> Count: {$sc['c']}\n";
}

$coupons = Db::name('user_consignment_coupon')
    ->where('user_id', $userId)
    ->order('update_time', 'desc')
    ->limit(5)
    ->select();
foreach ($coupons as $cp) {
    echo "Coupon ID: {$cp['id']}, Status: {$cp['status']}, CreateTime: " . date('Y-m-d H:i:s', $cp['create_time']) . ", UpdateTime: " . date('Y-m-d H:i:s', $cp['update_time']) . "\n";
}
