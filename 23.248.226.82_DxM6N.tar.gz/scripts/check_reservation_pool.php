<?php
/**
 * 检查盲盒预约池状态
 * 统计预约情况、冻结资金、中签率等
 */

require dirname(__DIR__) . '/vendor/autoload.php';

use think\facade\Db;

// 初始化应用
$app = new think\App(dirname(__DIR__));
$app->initialize();

echo "\n";
echo "===========================================\n";
echo "      盲盒预约池状态检查\n";
echo "===========================================\n";
echo "检查时间: " . date('Y-m-d H:i:s') . "\n";
echo "-------------------------------------------\n\n";

// ========================================
// 1. 预约状态统计
// ========================================
echo "📊 【预约状态统计】\n";
echo "-------------------------------------------\n";

// 查询所有预约记录
$reservations = Db::name('trade_reservations')
    ->select()
    ->toArray();

$statusStats = [
    0 => ['name' => '待撮合', 'count' => 0, 'amount' => 0],
    1 => ['name' => '已中签', 'count' => 0, 'amount' => 0],
    2 => ['name' => '未中签', 'count' => 0, 'amount' => 0],
    3 => ['name' => '已取消', 'count' => 0, 'amount' => 0],
];

$totalFrozen = 0;
$bySession = [];
$byUser = [];

foreach ($reservations as $res) {
    $status = (int)$res['status'];
    $freezeAmount = (float)$res['freeze_amount'];
    $sessionId = (int)$res['session_id'];
    $userId = (int)$res['user_id'];
    
    if (isset($statusStats[$status])) {
        $statusStats[$status]['count']++;
        $statusStats[$status]['amount'] += $freezeAmount;
    }
    
    if ($status === 0) {
        $totalFrozen += $freezeAmount;
    }
    
    // 按场次统计
    if (!isset($bySession[$sessionId])) {
        $bySession[$sessionId] = [
            'total' => 0,
            'pending' => 0,
            'matched' => 0,
            'failed' => 0,
            'cancelled' => 0,
            'frozen_amount' => 0,
        ];
    }
    $bySession[$sessionId]['total']++;
    $bySession[$sessionId]['frozen_amount'] += ($status === 0 ? $freezeAmount : 0);
    
    switch ($status) {
        case 0: $bySession[$sessionId]['pending']++; break;
        case 1: $bySession[$sessionId]['matched']++; break;
        case 2: $bySession[$sessionId]['failed']++; break;
        case 3: $bySession[$sessionId]['cancelled']++; break;
    }
    
    // 按用户统计（仅待撮合）
    if ($status === 0) {
        if (!isset($byUser[$userId])) {
            $byUser[$userId] = ['count' => 0, 'amount' => 0];
        }
        $byUser[$userId]['count']++;
        $byUser[$userId]['amount'] += $freezeAmount;
    }
}

echo "总预约记录: " . count($reservations) . " 条\n\n";

foreach ($statusStats as $status => $data) {
    echo sprintf("%-10s: %5d 条  金额: %12s 元\n", 
        $data['name'], 
        $data['count'], 
        number_format($data['amount'], 2)
    );
}

echo "\n当前冻结资金: " . number_format($totalFrozen, 2) . " 元\n";

// ========================================
// 2. 按场次详细统计
// ========================================
echo "\n📊 【按场次统计】\n";
echo "-------------------------------------------\n";

if (empty($bySession)) {
    echo "暂无预约记录\n";
} else {
    // 获取场次信息
    $sessionIds = array_keys($bySession);
    $sessions = Db::name('collection_session')
        ->whereIn('id', $sessionIds)
        ->select()
        ->toArray();
    
    $sessionMap = [];
    foreach ($sessions as $session) {
        $sessionMap[$session['id']] = $session;
    }
    
    echo sprintf("\n%-5s %-30s %8s %8s %8s %8s %8s %15s\n", 
        "ID", "场次名称", "总预约", "待撮合", "已中签", "未中签", "已取消", "冻结金额"
    );
    echo str_repeat("-", 120) . "\n";
    
    foreach ($bySession as $sessionId => $stats) {
        $session = $sessionMap[$sessionId] ?? null;
        $sessionName = $session ? mb_substr($session['title'], 0, 28) : "未知场次";
        
        $winRate = $stats['matched'] > 0 
            ? round($stats['matched'] / ($stats['matched'] + $stats['failed']) * 100, 1) 
            : 0;
        
        echo sprintf("%-5d %-30s %8d %8d %8d %8d %8d %15s", 
            $sessionId,
            $sessionName,
            $stats['total'],
            $stats['pending'],
            $stats['matched'],
            $stats['failed'],
            $stats['cancelled'],
            number_format($stats['frozen_amount'], 2)
        );
        
        if ($stats['pending'] > 0) {
            echo " 🔄 进行中\n";
        } else {
            echo " (中签率: {$winRate}%)\n";
        }
        
        // 如果有待撮合的，显示更多细节
        if ($stats['pending'] > 0 && $session) {
            // 获取该场次的库存情况
            $items = Db::name('collection_item')
                ->where('session_id', $sessionId)
                ->where('status', '1')
                ->select()
                ->toArray();
            
            $totalStock = 0;
            foreach ($items as $item) {
                $totalStock += (int)$item['stock'];
            }
            
            // 获取寄售数量
            $consignCount = Db::name('collection_consignment')
                ->where('session_id', $sessionId)
                ->where('status', 1)
                ->count();
            
            $totalAvailable = $totalStock + $consignCount;
            
            echo "    └─ 可用库存: {$totalAvailable} (官方: {$totalStock} + 寄售: {$consignCount})\n";
            echo "    └─ 预计中签率: ";
            
            if ($stats['pending'] > 0) {
                $estimatedWinRate = min(100, round($totalAvailable / $stats['pending'] * 100, 1));
                echo "{$estimatedWinRate}%";
                
                if ($estimatedWinRate >= 100) {
                    echo " ✅ 库存充足\n";
                } elseif ($estimatedWinRate >= 50) {
                    echo " ⚠️ 库存紧张\n";
                } else {
                    echo " ❌ 库存不足\n";
                }
            }
        }
    }
}

// ========================================
// 3. 用户预约情况（TOP 20）
// ========================================
echo "\n📊 【活跃用户TOP 20】（待撮合）\n";
echo "-------------------------------------------\n";

if (empty($byUser)) {
    echo "当前无待撮合预约\n";
} else {
    // 按预约数量排序
    uasort($byUser, function($a, $b) {
        return $b['count'] - $a['count'];
    });
    
    $topUsers = array_slice($byUser, 0, 20, true);
    
    echo sprintf("%-10s %10s %15s %15s\n", "用户ID", "预约数", "冻结金额", "平均金额");
    echo str_repeat("-", 60) . "\n";
    
    foreach ($topUsers as $userId => $stats) {
        $avgAmount = $stats['count'] > 0 ? $stats['amount'] / $stats['count'] : 0;
        
        echo sprintf("%-10d %10d %15s %15s\n",
            $userId,
            $stats['count'],
            number_format($stats['amount'], 2),
            number_format($avgAmount, 2)
        );
    }
    
    echo str_repeat("-", 60) . "\n";
    echo "总参与用户数: " . count($byUser) . " 人\n";
    echo "平均每人预约: " . round(array_sum(array_column($byUser, 'count')) / count($byUser), 2) . " 单\n";
}

// ========================================
// 4. 今日预约统计
// ========================================
echo "\n📊 【今日预约统计】\n";
echo "-------------------------------------------\n";

$todayStart = strtotime(date('Y-m-d 00:00:00'));
$todayEnd = strtotime(date('Y-m-d 23:59:59'));

$todayReservations = Db::name('trade_reservations')
    ->where('create_time', '>=', $todayStart)
    ->where('create_time', '<=', $todayEnd)
    ->select()
    ->toArray();

$todayStats = [
    'total' => count($todayReservations),
    'amount' => 0,
    'users' => [],
];

foreach ($todayReservations as $res) {
    $todayStats['amount'] += (float)$res['freeze_amount'];
    $todayStats['users'][$res['user_id']] = 1;
}

echo "今日新增预约: {$todayStats['total']} 单\n";
echo "今日预约金额: " . number_format($todayStats['amount'], 2) . " 元\n";
echo "今日参与用户: " . count($todayStats['users']) . " 人\n";

if ($todayStats['total'] > 0) {
    echo "平均预约金额: " . number_format($todayStats['amount'] / $todayStats['total'], 2) . " 元\n";
}

// ========================================
// 5. 综合分析
// ========================================
echo "\n📊 【综合分析】\n";
echo "===========================================\n";

$totalPending = $statusStats[0]['count'];
$totalMatched = $statusStats[1]['count'];
$totalFailed = $statusStats[2]['count'];
$totalCancelled = $statusStats[3]['count'];

echo "预约池活跃度: ";
if ($totalPending > 100) {
    echo "🔥 非常活跃 ({$totalPending}单待撮合)\n";
} elseif ($totalPending > 50) {
    echo "✅ 活跃 ({$totalPending}单待撮合)\n";
} elseif ($totalPending > 10) {
    echo "⚠️ 一般 ({$totalPending}单待撮合)\n";
} else {
    echo "❌ 较冷清 ({$totalPending}单待撮合)\n";
}

if ($totalMatched + $totalFailed > 0) {
    $historicalWinRate = round($totalMatched / ($totalMatched + $totalFailed) * 100, 2);
    echo "历史中签率: {$historicalWinRate}%\n";
}

if ($totalCancelled > 0) {
    echo "取消率: " . round($totalCancelled / count($reservations) * 100, 2) . "%\n";
}

echo "\n冻结资金风险:\n";
echo "  - 当前冻结: " . number_format($totalFrozen, 2) . " 元\n";
echo "  - 待撮合: {$totalPending} 单\n";
if ($totalPending > 0) {
    echo "  - 平均冻结: " . number_format($totalFrozen / $totalPending, 2) . " 元/单\n";
}

echo "\n===========================================\n";
echo "检查完成\n";
echo "===========================================\n\n";
