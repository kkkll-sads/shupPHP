<template>
    <!-- 这个文件可以留空，因为充值订单不需要编辑表单，只有查看和审核功能 -->
</template>

<script setup lang="ts">
// 充值订单不需要编辑表单
</script>

<style scoped lang="scss"></style>

