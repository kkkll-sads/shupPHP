export const enum taskStatus {
    Waiting,
    Connecting,
    Executing,
    Success,
    Failed,
    Unknown,
}
