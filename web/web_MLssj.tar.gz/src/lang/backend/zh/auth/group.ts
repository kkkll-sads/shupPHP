export default {
    GroupName: '组名',
    'Group name': '组别名称',
    jurisdiction: '权限',
    'Parent group': '上级分组',
    'The parent group cannot be the group itself': '上级分组不能是分组本身',
    'Manage subordinate role groups here': '在此管理下级角色组（您拥有下级角色组的所有权限并且拥有额外的权限，不含同级）',
}
