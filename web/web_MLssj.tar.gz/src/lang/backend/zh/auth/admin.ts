export default {
    username: '用户名',
    nickname: '昵称',
    group: '角色组',
    avatar: '头像',
    email: '电子邮箱',
    mobile: '手机号',
    'Last login': '最后登录',
    Password: '密码',
    'Please leave blank if not modified': '不修改请留空',
    'Personal signature': '个性签名',
    'Administrator login': '管理员登录名',
}
