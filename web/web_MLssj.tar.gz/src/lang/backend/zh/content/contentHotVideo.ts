export default {
    Id: 'ID',
    Title: '标题',
    Summary: '摘要',
    'Video Url': '视频地址',
    'Cover Image': '封面图',
    Status: '状态',
    'Publish Time': '发布时间',
    Sort: '排序',
    'View Count': '浏览量',
    Createtime: '创建时间',
    Updatetime: '更新时间',
    'Title is required': '标题不能为空',
    'Status value is incorrect': '状态值不正确',
    'Value is incorrect': '取值不正确',
}

