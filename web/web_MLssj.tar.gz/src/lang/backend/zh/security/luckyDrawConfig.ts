export default {
    'security.luckyDrawConfig.config_key': '配置键',
    'security.luckyDrawConfig.config_value': '配置值',
    'security.luckyDrawConfig.remark': '备注',
    'security.luckyDrawConfig.daily_draw_limit': '每天允许抽奖次数',
    'security.luckyDrawConfig.draw_score_cost': '每次抽奖消耗积分',
    'security.luckyDrawConfig.daily_limit_reset_hour': '每日限制重置时间(小时)',
    'security.luckyDrawConfig.prize_send_auto': '是否自动发放奖品',
}

