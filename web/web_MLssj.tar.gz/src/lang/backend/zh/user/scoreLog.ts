export default {
    integral: '积分',
    'Change points': '变更积分',
    'Current points': '当前积分',
    'Please enter the change amount of points': '请输入积分变更数额',
    'Points after change': '变更后积分',
    'Please enter change remarks / description': '请输入变更备注/说明',
}
