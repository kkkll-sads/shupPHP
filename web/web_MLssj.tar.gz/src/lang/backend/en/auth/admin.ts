export default {
    username: 'Username',
    nickname: 'Nickname',
    group: 'Group',
    avatar: 'Avatar',
    email: 'Email',
    mobile: 'Mobile Number',
    'Last login': 'Last login',
    Password: 'Password',
    'Please leave blank if not modified': 'Please leave blank if you do not modify.',
    'Personal signature': 'Personal Signature',
    'Administrator login': 'Administrator Login Name',
}
