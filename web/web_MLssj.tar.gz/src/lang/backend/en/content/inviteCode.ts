export default {
    code: 'Invite Code',
    creator: 'Creator(Mobile)',
    upuser: 'Upline User(Mobile)',
    child_count: 'Child Users',
    status: 'Status',
    use_count: 'Used Count',
    max_use: 'Max Usage',
    expire_time: 'Expire Time',
    remark: 'Remark',
    auto_generate_tip: 'Leave blank to auto-generate',
    max_use_tip: '0 means unlimited usage',
    expire_time_tip: 'Leave blank for never expire',
    'Invite code management': 'Invite Code Management',
    'Add invite code': 'Add Invite Code',
    'Edit invite code': 'Edit Invite Code',
    'Delete invite code': 'Delete Invite Code',
}

