export default {
    'security.luckyDrawConfig.config_key': 'Config Key',
    'security.luckyDrawConfig.config_value': 'Config Value',
    'security.luckyDrawConfig.remark': 'Remark',
    'security.luckyDrawConfig.daily_draw_limit': 'Daily Draw Limit',
    'security.luckyDrawConfig.draw_score_cost': 'Score Cost Per Draw',
    'security.luckyDrawConfig.daily_limit_reset_hour': 'Daily Limit Reset Hour',
    'security.luckyDrawConfig.prize_send_auto': 'Auto Send Prize',
}

