export default {
    GroupName: 'Group name',
    'Group name': 'Group name',
    jurisdiction: 'Permissions',
}
