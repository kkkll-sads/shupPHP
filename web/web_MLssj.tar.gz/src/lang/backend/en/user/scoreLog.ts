export default {
    integral: 'Integral',
    'Change points': 'Change points',
    'Current points': 'Current points',
    'Please enter the change amount of points': 'Please enter the change amount of points',
    'Points after change': 'Points after change',
    'Please enter change remarks / description': 'Please enter change remarks/description',
}
