export default {
    remarks: 'remarks',
    'Primary key': 'Primary key',
    'Primary key (Snowflake ID)': 'Primary key (Snowflake ID)',
    'Disable Search': 'Disable Search',
    'Weight (drag and drop sorting)': 'Weight (drag and drop sorting)',
    'Status:0=Disabled,1=Enabled': 'Status:0=Disabled,1=Enabled',
    'Remote Select (association table)': 'Remote Select (association table)',
    'Remote Select (Multi)': 'Remote Select (Multi)',
    'Radio:opt0=Option1,opt1=Option2': 'Radio:opt0=Option1,opt1=Option2',
    'Checkbox:opt0=Option1,opt1=Option2': 'Checkbox:opt0=Option1,opt1=Option2',
    Multi: '(Multi)',
    'Select:opt0=Option1,opt1=Option2': 'Select:opt0=Option1,opt1=Option2',
    'Switch:0=off,1=on': 'Switch:0=off,1=on',
    'Time date (timestamp storage)': 'Time date (timestamp storage)',
    'If left blank, the verifier title attribute will be filled in automatically':
        'If left blank, the verifier title attribute will be filled in automatically',
    'Weight (automatically generate drag sort button)': 'Weight (automatically generate drag sort button)',
    'If it is not input, it will be automatically analyzed by the controller':
        'If it is not input, it will be automatically analyzed by the controller',
}
