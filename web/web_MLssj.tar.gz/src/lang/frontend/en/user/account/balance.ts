export default {
    'Change time': 'Change time',
    'Current balance': 'Current balance',
    'Balance after change': 'Balance after change',
    'Balance change record': 'Balance change record',
}
