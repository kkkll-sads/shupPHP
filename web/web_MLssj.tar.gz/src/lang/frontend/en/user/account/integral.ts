export default {
    'Change time': 'Change time',
    'Current points': 'Current points',
    'Points after change': 'Points after change',
    'Score change record': 'Score change record',
}
