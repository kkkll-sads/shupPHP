export default {
    Subtitle: 'Stay up-to-date with our latest announcements',
    'View count': 'Views: {count}',
    'Back to list': 'Back to list',
    'Not found': 'News not found or unpublished.',
}


