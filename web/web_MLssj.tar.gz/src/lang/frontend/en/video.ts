export default {
    Subtitle: 'Discover featured videos about our company and financial products.',
    'Video missing': 'Video is not available.',
}


