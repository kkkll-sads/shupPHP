export default {
    Subtitle: '精选视频带你全面了解公司与产品亮点',
    'Video missing': '视频资源不存在或暂不可用',
}


