export default {
    'Account information': '账户信息',
    profile: '个人资料',
    'Filled in': '已填写',
    'Not filled in': '未填写',
    mobile: '手机号',
    email: '电子邮箱',
    'Last login IP': '最后登录IP',
    'Last login': '最后登录',
    'Growth statistics': '增长统计',
}
