export default {
    'Change time': '变更时间',
    'Current balance': '当前余额',
    'Balance after change': '变更后余额',
    'Balance change record': '余额变更记录',
}
