export default {
    Subtitle: '了解公司最新要闻与动态',
    'View count': '浏览量：{count}',
    'Back to list': '返回列表',
    'Not found': '资讯不存在或已下架',
}


